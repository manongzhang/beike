<?php
	require_once "./vendor/autoload.php";
	use EasyWeChat\Foundation\Application;
	$arr = array(
		'app_id' => 'wx998482038f3d9c0c',
		'mch_id' => '1339371601',
		'key' => 'sixstarphpwebjavaissoeasyabcde89',
		'notify_uri'=> "http://101.201.236.9/call.php",
	);
	use EasyWeChat\Payment\Order;
	$obj = new Application($arr);	
	$payment = $obj->payment;
	$arrAttribute = array(
		'body'=>'thi sis test',
		'total_fee'=>8888,
		'out_trade_no'=>time().mt_rand(100,999),
		'trade_type' =>'NATIVE',
	);
	$objorder = new Order($arrAttribute);

	$result = $payment->prepare($objorder);
	var_dump($result);
?>
