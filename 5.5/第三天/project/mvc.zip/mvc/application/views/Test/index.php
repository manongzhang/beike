<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<center>
    <h1>用户注册</h1>

    <form action="index.php?act=test/register" method="post" id="form">
        <table>
            <tr>
                <td>用户名：</td>
                <td><input type="text" name="username"/>
                <span style="color: red" id="usernameVerify"></span>
                </td>
            </tr>
            <tr>
                <td>密码：</td>
                <td><input type="text" name="password"/></td>
            </tr>
            <tr>
                <td>重复密码：</td>
                <td><input type="text" name="rePwd"/></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="button" value="注册" id="but"/></td>
            </tr>
        </table>
    </form>
</center>
</body>
</html>
<script src="public/lib/jquery/jquery.js"></script>
<script>
    var verify = false;
    $('[name=username]').blur(function(){
        var username = $(this).val();
        $.ajax({
            data:{username:username},
            type:'post',
            dataType:'json',
            url:'index.php?act=test/usernameOnly',
            success: function (res) {
                console.log(res);
                if(res == 0){
                    $('#usernameVerify').text('用户名不可重复');
                    verify = false;
                }else{
                    $('#usernameVerify').text('');
                    verify = true;
                }
            }
        });
    });

    $("#but").click(function () {
        if(verify == 1){
            $('#form').submit();
        }
    });
</script>