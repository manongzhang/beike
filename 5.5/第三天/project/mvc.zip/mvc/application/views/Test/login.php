<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<center>
    <h1>用户登陆</h1>

    <form action="index.php?act=test/login" method="post">
        <table>
            <tr>
                <td>用户名：</td>
                <td><input type="text" name="username"/></td>
            </tr>
            <tr>
                <td>密码：</td>
                <td><input type="text" name="password"/></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="登陆"/>&nbsp;
                    <a href="index.php?act=test/index"><input type="button" value="注册用户"/></a>
                </td>
            </tr>
        </table>
    </form>
</center>
</body>
</html>