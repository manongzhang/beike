<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<center>
    <h1>信息展示</h1>
    <table border="1">
        <tr>
            <th>编号</th>
            <th>标题</th>
            <th>用户</th>
            <th>地址</th>
            <th>发布时间</th>
            <th>是否审核</th>
            <th>操作</th>
        </tr>
        <?php foreach($data as $key => $val){?>
            <tr>
                <td><?php echo $val['test_id'];?></td>
                <td><?php echo $val['test_name'];?></td>
                <td><?php echo $val['test_user'];?></td>
                <td><?php echo $val['test_address'];?></td>
                <td><?php echo $val['addtime'];?></td>
                <td><?php if($val['status'] == 1){echo '已审核';}else{echo '未审核';};?></td>
                <td><a href="#">查看</a> | <a href="index.php?act=test/dataDel&test_id=<?php echo $val['test_id'];?>">删除</a></td>
            </tr>
        <?php }?>
    </table>
    <a href="index.php?act=test/clearLoginStatus"><button>清除登陆状态</button></a>
</center>
</body>
</html>