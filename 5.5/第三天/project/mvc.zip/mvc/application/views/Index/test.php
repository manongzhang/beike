<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<center>
    <h1>文件上传</h1>
        <form action="index.php?act=index/uploads" method="post" enctype="multipart/form-data">
        <table>
            <tr>
                <td>请选择文件：</td>
                <td><input type="file" name="photo"/></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="上传"/></td>
            </tr>
        </table>
    </form>
</center>
</body>
</html>