<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<style>
    #div{
        width: 500px;
        height: 500px;
        margin:auto;

    }
    img{
        width: 500px;
        height: 500px;
        display: none;
    }
    #btn {
        width: 300px;
        position: absolute;
        left: 0;
        bottom: 0;
        text-align: center;
    }

    .btn a {
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
    }
    .red {
        background: red;
    }
    .white {
        background: blue;
    }
</style>
    <div id="div">
        <?php foreach($data as $key => $val){?>
            <img src="<?php echo "http://47.93.42.222".$val['url'];?>" id="<?php echo $key;?>"/>
        <?php }?>
    </div>
    <div id="div" style="height: 50px;margin-left: 625px;" class="btn">
        <?php foreach($data as $key => $val){?>
            <a href="javascript:" id="<?php echo 'input'.$key;?>" name="click" class="white"></a>
        <?php }?>
    </div>
<button id="prev" style="margin-left: 600px;">上一张</button>
<button id="next">下一张</button>


</body>
</html>
<script src="jquery.min.js"></script>
<script>
    $(function(){
        $('#0').attr('class','show');
        $('.show').css('display','block');
        $('#input0').attr('class','red');
        f = setInterval(swiper,1000);
    });

    $('[name=click]').click(function () {
        clearInterval(f);
        var obj = $(this);
        var id = obj.attr('id');
        var new_id = id.substr(5,1);

        $('img').attr('class','').css('display','none');
        $('#'+new_id).attr('class','show').css('display','block');

        $('a').attr('class','white');
        $('#'+id).attr('class','red');
    });

    $('img').hover(function(){
        clearInterval(f);
    });

    $('img').mouseout(function(){
        f = setInterval(swiper,1000);
    });

    $('a').mouseout(function(){
        f = setInterval(swiper,1000);
    });

    $('button').mouseout(function(){
        f = setInterval(swiper,1000);
    });
    $('button').hover(function(){
        clearInterval(f);
    });
    function swiper()
    {
        var num = $('img').size();
        var id = $('.show').attr('id');
        id = parseInt(id);
        var new_id = id + 1;
        if(id + 1 > num - 1){
            new_id = 0;
        }else{
            new_id = id + 1;
        }
        $('#'+id).attr('class','').css('display','none');
        $('#'+new_id).attr('class','show').css('display','block');
        $('#input'+id).attr('class','white');
        $('#input'+new_id).attr('class','red');
    }

    $('#prev').click(function () {
        clearInterval(f);
        var num = $('img').size();
        var id = $('.show').attr('id');
        id = parseInt(id);
        var new_id;
        if(id - 1 < 0){
            new_id = num - 1;
        }else{
            new_id = id - 1;
        }
        $('#'+id).attr('class','').css('display','none');
        $('#'+new_id).attr('class','show').css('display','block');
        $('#input'+id).attr('class','white');
        $('#input'+new_id).attr('class','red');
    });

    $('#next').click(function () {
        clearInterval(f);
        var num = $('img').size();

        var id = $('.show').attr('id');
        id = parseInt(id);
        var new_id = id + 1;

        if(id + 1 > num - 1){
            new_id = 0;
        }else{
            new_id = id + 1;
        }

        $('#'+id).attr('class','').css('display','none');
        $('#'+new_id).attr('class','show').css('display','block');
        $('#input'+id).attr('class','white');
        $('#input'+new_id).attr('class','red');
    });

</script>