<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<center>
    <h1>图片列表展示</h1>
    <a href="index.php?act=index/index"><button>添加新图片</button></a><br/>
    <a href="index.php?act=index/swiper"><button>查看轮播图</button></a>
    <table border="1">
        <tr>
            <th>图片ID</th>
            <th>图片预览</th>
            <th>操作</th>
        </tr>
        <?php foreach($data['data'] as $key => $val){?>
            <tr>
                <td><?php echo $val['photo_id'];?></td>
                <td><img src="<?php echo "http://47.93.42.222".$val['url']; ?>" width="50px;" height="50px;"/></td>
                <td>
                    <a href="index.php?act=index/photo_del&id=<?php echo $val['photo_id'];?>">删除</a>
                </td>
            </tr>
        <?php }?>
    </table>
    <a href="index.php?act=index/photo_list&page=1">首页</a>
    <a href="index.php?act=index/photo_list&page=<?php echo $data['page'] - 1 < 1 ? 1 : $data['page'] - 1 ;?>">上一页</a>
    <a href="index.php?act=index/photo_list&page=<?php echo $data['page'] - 1 > $data['pageNum'] ? $data['pageNum'] : $data['page'] + 1 ;?>">下一页</a>
    <a href="index.php?act=index/photo_list&page=<?php echo $data['pageNum'];?>">尾页</a>
</center>
</body>
</html>