﻿<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <title>制造工业</title>
    ﻿<meta charset="UTF-8">
    <base href="<?php echo __PUBLIC__;?>"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="format-detection" content="telephone=no">
<meta name="renderer" content="webkit">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="alternate icon" type="image/png" href="images/favicon.png">
<link rel='icon' href='favicon.ico' type='image/x-ico' />
<meta name="description" content="" />
<meta name="keywords" content="" />
<link rel="stylesheet" href="css/default.min.css?t=227" />
<!--[if (gte IE 9)|!(IE)]><!-->
<script type="text/javascript" src="lib/jquery/jquery.min.js"></script>
<!--<![endif]-->
<!--[if lte IE 8 ]>
<script src="http://libs.baidu.com/jquery/1.11.3/jquery.min.js"></script>
<script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="lib/amazeui/amazeui.ie8polyfill.min.js"></script>
<![endif]-->
<script type="text/javascript" src="lib/handlebars/handlebars.min.js"></script>
<script type="text/javascript" src="lib/iscroll/iscroll-probe.js"></script>
<script type="text/javascript" src="lib/amazeui/amazeui.min.js"></script>
<script type="text/javascript" src="lib/raty/jquery.raty.js"></script>
<script type="text/javascript" src="js/main.min.js?t=1"></script>
</head>
<body>
    <header class="header">
    <div class="header-container">
        <div class="header-div pull-left">
                <a class="header-logo">
                    <img src="images/logo.png" />
                </a>
            <button class="am-show-sm-only am-collapsed font f-btn" data-am-collapse="{target: '.header-nav'}">&#xe68b;</button>
        </div>
        
<!--        头部导航栏-->
        <nav>
            <ul class="header-nav am-collapse">
                <?php foreach($nav['navData'] as $key => $val){?>
                    <li class="<?php if($nav['nav_id'] == $val['nav_order']){ echo 'on';}?>"><a href="<?php echo $val['nav_url'].'&nav_id='.$val['nav_order'];?>" class="nav"><?php echo $val['nav_name'];?></a></li>
                <?php }?>
            </ul>
            <div class="header-serch  am-hide-md-down">
                <input type="text" name="name" value="" />
                <em class="font">&#xe632;</em>
            </div>
        </nav>


    </div>
</header>
    <div  class="am-cf"></div>
    <div class="am-slider am-slider-default" data-am-flexslider="{playAfterPaused: 8000}">
        <ul class="am-slides">
            <?php foreach($data['swiperData'] as $key => $val){?>
                <li><img src="<?php echo $val['img'];?>"/></li>
            <?php }?>
        </ul>
    </div>
<!--    热门商品-->
<div class="copyrights">Collect from <a href="http://www.cssmoban.com/" >网页模板</a></div>
    <div class="index-nav">
        <div class="cms-g">
            <?php foreach($data['goodsData'] as $key => $val){?>
                <div class="am-u-sm-6 am-u-md-6 am-u-lg-3">
                    <div class="index-nav-item">
                        <div class="index-nav-img">
                            <img src="<?php echo $val['img_url'];?>" />
                        </div>
                        <div class="index-nav-info">
                            <h1><?php echo $val['goods_name'];?></h1>
                            <h2><?php echo $val['goods_desc'];?></h2>
                            <em class="font"><a href="http://47.93.42.222/index.php?act=goods/product_list">详细介绍&#xe72f;</a></em>
                        </div>
                    </div>
                </div>
            <?php }?>
        </div>
    </div>


    <div class="index-content">
        <div class="cms-g">
            <div class="am-u-sm-12 am-u-md-12 am-u-lg-4">
                <div class="index-content-left">
                    <h1>产品中心</h1>
                    <div class="am-slider am-slider-default" data-am-flexslider id="demo-slider-0">
                        <ul class="am-slides">
                            <?php foreach($data['imgData'] as $key => $val){?>
                                <li><img src="<?php echo $val['hot_img'];?>" /></li>
                            <?php }?>
                        </ul>
                    </div>
                    <strong><a href="#"><?php echo $data['descData']['0']['hot_desc'];?></a></strong>
                    <em><a href="#">详情介绍<i class="font">&#xe78d;</i></a></em>
                </div>
            </div>
            <div class="am-u-sm-12 am-u-md-12 am-u-lg-4">
                <div class="index-content-center">
                    <h1>新闻动态<a href="#">MORE<i class="font">&#xe78d;</i></a></h1>
                    <ul>
                        <?php foreach($data['newData'] as $key => $val){?>
                            <li><a href="<?php echo __URL__.'?act=goods/indexNew&new_id='.$val['new_id'];?>"><span><?php echo $val['new_name'];?></span><em><?php echo $val['addtime'];?></em></a></li>
                        <?php }?>
                    </ul>
                </div>
            </div>
            <div class="am-u-sm-12 am-u-md-12 am-u-lg-4">
                <div class="index-content-right">
                    <h1>产品应用<a href="#">MORE<i class="font">&#xe78d;</i></a></h1>
                    <img src="images/index-content-right-01.jpg"/>
                    <ul>
                        <?php foreach($data['applyData'] as $key => $val){?>
                            <li><a href="<?php echo __URL__.'?act=goods/indexApply&apply_id='.$val['apply_id'];?>"><?php echo $val['apply_name'];?></a></li>
                        <?php }?>
                    </ul>
                </div>
            </div>
        </div>
    </div>


    ﻿<footer>
    <div class="cms-g">
        <div class="footer">
            <ul>
                <li><a href="#"><span>网站地图</span></a></li>
                <li><a href="#"><span>访问统计</span></a></li>
                <li><a href="#"><span>友情链接</span></a></li>
                <li><a href="#"><span>法律申明</span></a></li>
            </ul>
            <span style="color:#fff;"><a href="http://www.haothemes.com/" target="_blank" title="好主题">好主题</a>提供 - More Templates <a href="http://www.cssmoban.com/" target="_blank" title="模板之家">模板之家</a> - Collect from <a href="http://www.cssmoban.com/" title="网页模板" target="_blank">网页模板</a></span>
        </div>
        
    </div>
</footer>
</body>
</html>