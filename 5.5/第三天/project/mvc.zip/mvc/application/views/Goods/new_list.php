﻿<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <title>制造工业</title>
    ﻿<meta charset="UTF-8">
    <base href="<?php echo __PUBLIC__;?>"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="format-detection" content="telephone=no">
<meta name="renderer" content="webkit">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="alternate icon" type="image/png" href="images/favicon.png">
<link rel='icon' href='favicon.ico' type='image/x-ico' />
<meta name="description" content="" />
<meta name="keywords" content="" />
<link rel="stylesheet" href="css/default.min.css?t=227" />
<!--[if (gte IE 9)|!(IE)]><!-->
<script type="text/javascript" src="lib/jquery/jquery.min.js"></script>
<!--<![endif]-->
<!--[if lte IE 8 ]>
<script src="http://libs.baidu.com/jquery/1.11.3/jquery.min.js"></script>
<script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="lib/amazeui/amazeui.ie8polyfill.min.js"></script>
<![endif]-->
<script type="text/javascript" src="lib/handlebars/handlebars.min.js"></script>
<script type="text/javascript" src="lib/iscroll/iscroll-probe.js"></script>
<script type="text/javascript" src="lib/amazeui/amazeui.min.js"></script>
<script type="text/javascript" src="lib/raty/jquery.raty.js"></script>
<script type="text/javascript" src="js/main.min.js?t=1"></script>
</head>
<body>
    <header class="header">
    <div class="header-container">
        <div class="header-div pull-left">
                <a class="header-logo">
                    <img src="images/logo.png" />
                </a>
            <button class="am-show-sm-only am-collapsed font f-btn" data-am-collapse="{target: '.header-nav'}">&#xe68b;</button>
        </div>
        

        <nav>
            <ul class="header-nav am-collapse">
                <?php foreach($nav['navData'] as $key => $val){?>
                    <li class="<?php if($nav['nav_id'] == $val['nav_order']){ echo 'on';}?>"><a href="<?php echo $val['nav_url'].'&nav_id='.$val['nav_order'];?>" class="nav"><?php echo $val['nav_name'];?></a></li>
                <?php }?>
            </ul>
            <div class="header-serch  am-hide-md-down">
                <input type="text" name="name" value="" />
                <em class="font">&#xe632;</em>
            </div>
        </nav>


    </div>
</header>
    <div class="com-banner">
        <img src="http://47.93.42.222/public/images/index_banner.jpg" />
    </div>
    <div class="com-container">
        <div class="cms-g">
            <div class="am-hide-sm-only am-u-md-3 am-u-lg-3">
                <div class="com-nav-left">
                    <h1><em>新闻中心</em><i>NEWS</i></h1>
                    <ul>
                        <?php foreach($data['new_class_data'] as $key => $val){?>
                            <li class="<?php if($data['new_class_id'] == $val['new_class_id']){echo 'on';}?>"><a href="javascript:void (0);" class="getNewData" new_class_id="<?php echo $val['new_class_id'];?>"><?php echo $val['class_name'];?></a></li>
                        <?php }?>
                    </ul>
                </div>
            </div>
            <div class="am-u-sm-12 am-u-md-9 am-u-lg-9">
                <div class="com-nav-title">
                    <a href="#doc-oc-demo1" class="font am-show-sm-only" data-am-offcanvas>&#xe68b;</a>
                    <span><?php echo $data['new_class_data'][0]['class_name'];?></span>
                </div>

                <div id="contentData">
                    <div class="new-list">
                        <ul>
                            <?php foreach($data['newData'] as $key => $val){?>
                                <li><a href="javascript:void(0);" class="contentData" new_id="<?php echo $val['new_id'];?>"><span><?php echo $val['new_name'];?></span><em><?php echo $val['addtime'];?></em></a></li>
                            <?php }?>
                        </ul>
                    </div>
                    <div class="page-list">
                        <a href="#"><<</a>
                        <a href="#"><</a>
                        <a href="#" class="num">1</a>
                        <a href="#" class="num">2</a>
                        <a href="#" class="num">3</a>
                        <a href="#" class="on">4</a>
                        <a href="#" class="num">5</a>
                        <a href="#" class="num">6</a>
                        <a href="#">></a>
                        <a href="#">>></a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div id="doc-oc-demo1" class="am-offcanvas">
        <div class="am-offcanvas-bar">
            <div class="am-offcanvas-content com-nav-left com-nav-left1">
                <ul>
                    <li class="on"><a href="#">公司新闻</a></li>
                    <li><a href="#">产品资讯</a></li>
                    <li><a href="#">营销动态</a></li>
                </ul>
            </div>
        </div>
    </div>
    ﻿<footer>
    <div class="cms-g">
        <div class="footer">
            <ul>
                <li><a href="#"><span>网站地图</span></a></li>
                <li><a href="#"><span>访问统计</span></a></li>
                <li><a href="#"><span>友情链接</span></a></li>
                <li><a href="#"><span>法律申明</span></a></li>
            </ul>
            <span style="color:#fff;"><a href="http://www.haothemes.com/" target="_blank" title="好主题">好主题</a>提供 - More Templates <a href="http://www.cssmoban.com/" target="_blank" title="模板之家">模板之家</a> - Collect from <a href="http://www.cssmoban.com/" title="网页模板" target="_blank">网页模板</a></span>
        </div>   </div>
</footer>
</body>
</html>
<script>
    $(document).on('click','.contentData',function(){
        var obj = $(this);
        var span = obj.text();
        var new_id = obj.attr('new_id');
        new_id = parseInt(new_id);
        console.log(new_id);
        var prev_id;
        if(new_id - 1 < 1){
            prev_id = 1;
        }else{
            prev_id = new_id - 1;
        }

        var next_id = new_id + 1;
        $.ajax({
            url:'http://47.93.42.222/index.php?act=goods/new_info',
            type:'post',
            dataType:'json',
            data:{new_id:new_id},
            success:function(res){
                console.log(res);
                if(res == null){
                    $("#contentData").html('暂时还没有相应的新闻详情');
                }else{
                    var str = '<div class="com-nav-content"><span>'+res+'</span></div><div class="com-info-page"><a href="javascript:void(0);" class="contentData" new_id="'+prev_id+'">上一篇</a><a href="javascript:void(0);" class="contentData" new_id="'+next_id+'">下一篇</a></div>';
                    $("#contentData").html(str);
                }
            }
        });
    });


    $(document).on('click','.getNewData', function () {
        var obj = $(this);
        var span = obj.text();
        var new_class_id = obj.attr('new_class_id');
        $('.com-nav-left ul li').attr('class','');
        obj.parent().attr('class','on');
        $.ajax({
            url:'http://47.93.42.222/index.php?act=goods/getNewData',
            type:'post',
            dataType:'json',
            data:{new_class_id:new_class_id},
            success:function(res){
                console.log(res);
                if(res.length == 0){
                    $('#contentData').html('暂时还没有新闻');
                    $('.com-nav-title span').text(span);
                }else{
                    var str = '<div class="new-list"><ul>';
                    $.each(res,function(k,v){
                        str += '<li><a href="javascript:void(0);" class="contentData" new_id="'+ v.new_id+'"><span>'+ v.new_name+'</span><em>'+ v.addtime+'</em></a></li>';
                    });
                    str += '</ul></div><div class="page-list"><a href="#"><<</a><a href="#"><</a><a href="#" class="num">1</a><a href="#" class="num">2</a><a href="#" class="num">3</a><a href="#" class="on">4</a><a href="#" class="num">5</a><a href="#" class="num">6</a><a href="#">></a><a href="#">>></a></div>';
                    $('#contentData').html(str);
                    $('.com-nav-title span').text(span);
                }
            }
        });
    });
</script>