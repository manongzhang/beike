﻿<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <title>制造工业</title>
    ﻿<meta charset="UTF-8">
    <base href="<?php echo __PUBLIC__;?>"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="format-detection" content="telephone=no">
<meta name="renderer" content="webkit">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="alternate icon" type="image/png" href="images/favicon.png">
<link rel='icon' href='favicon.ico' type='image/x-ico' />
<meta name="description" content="" />
<meta name="keywords" content="" />
<link rel="stylesheet" href="css/default.min.css?t=227" />
<!--    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />-->
<!--    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />-->
<!--    <style type="text/css">-->
<!--        body, html,#allmap {width: 100%;height: 100%;overflow: hidden;margin:0;font-family:"微软雅黑";}-->
<!--    </style>-->
    <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=odMsOUy0vhxh0GqjIPt7LoB5G8MooDSv"></script>
<!--[if (gte IE 9)|!(IE)]><!-->
<script type="text/javascript" src="lib/jquery/jquery.min.js"></script>
<!--<![endif]-->
<!--[if lte IE 8 ]>
<script src="http://libs.baidu.com/jquery/1.11.3/jquery.min.js"></script>
<script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="lib/amazeui/amazeui.ie8polyfill.min.js"></script>
<![endif]-->
<script type="text/javascript" src="lib/handlebars/handlebars.min.js"></script>
<script type="text/javascript" src="lib/iscroll/iscroll-probe.js"></script>
<script type="text/javascript" src="lib/amazeui/amazeui.min.js"></script>
<script type="text/javascript" src="lib/raty/jquery.raty.js"></script>
<script type="text/javascript" src="js/main.min.js?t=1"></script>

    <style type="text/css">
        html, body { margin: 0; padding: 0; }
        .iw_poi_title { color: #CC5522; font-size: 14px; font-weight: bold; overflow: hidden; padding-right: 13px; white-space: nowrap; }
        .iw_poi_content { font: 12px arial,sans-serif; overflow: visible; padding-top: 4px; white-space: -moz-pre-wrap; word-wrap: break-word; }
    </style>
    <script type="text/javascript" src="http://api.map.baidu.com/api?key=&v=1.1&services=true"></script>

</head>
<body>
    <header class="header">
    <div class="header-container">
        <div class="header-div pull-left">
                <a class="header-logo">
                    <img src="images/logo.png" />
                </a>
            <button class="am-show-sm-only am-collapsed font f-btn" data-am-collapse="{target: '.header-nav'}">&#xe68b;</button>
        </div>
        

        <nav>
            <ul class="header-nav am-collapse">
                <?php foreach($nav['navData'] as $key => $val){?>
                    <li class="<?php if($nav['nav_id'] == $val['nav_order']){ echo 'on';}?>"><a href="<?php echo $val['nav_url'].'&nav_id='.$val['nav_order'];?>" class="nav"><?php echo $val['nav_name'];?></a></li>
                <?php }?>
            </ul>
            <div class="header-serch  am-hide-md-down">
                <input type="text" name="name" value="" />
                <em class="font">&#xe632;</em>
            </div>
        </nav>


    </div>
</header>
    <div class="com-banner">
        <img src="http://47.93.42.222/public/images/index_banner.jpg" />
    </div>
    <div class="com-container">
        <div class="cms-g">
            <div class="contact">
                <h1>
                    <em>CONTACT 联系我们</em>
                    <span>
                        <a href="#">联系我们</a>
                        <a href="#">在线客服</a>
                    </span>
                </h1>
                <div class="am-u-md-12 am-u-md-5 am-u-lg-5">
                    <div class="contact-left">
                        <h1>
                            <strong class="f-toe">大冶市云阿拉丁科技有限公司</strong>
                            <span class="f-toe">Daye Aladdin Technology Co., Ltd.</span>
                        </h1>
                        <ul>
                            <li><span>业务质询一：</span><a href="#">467843489</a></li>
                            <li><span>业务质询二：</span><a href="#">467843489</a></li>
                            <li><span>咨询电话：</span>0714-8878313</li>
                            <li><span>公司传真：</span>0714-8878313</li>
                            <li><span>地址：</span>大冶大道116金惠小区好太太总部2楼</li>
                            <li><span>邮编：</span>435100</li>
                            <li><span>网址：</span><a href="http://www.cssmoban.com">http://www.cssmoban.com</a></li>
                        </ul>
                    </div>
                </div>
                <div class="am-u-sm-12 am-u-md-7 am-u-lg-7">
                    <div class="contact-right">
<!--                        <div style="width:100%;height:400px;border:#ccc solid 1px;" id="dituContent"></div>-->
                        <div id="allmap" style="width:100%;height:400px;border:#ccc solid 1px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    ﻿<footer>
    <div class="cms-g">
        <div class="footer">
            <ul>
                <li><a href="#"><span>网站地图</span></a></li>
                <li><a href="#"><span>访问统计</span></a></li>
                <li><a href="#"><span>友情链接</span></a></li>
                <li><a href="#"><span>法律申明</span></a></li>
            </ul>
            <span style="color:#fff;"><a href="http://www.haothemes.com/" target="_blank" title="好主题">好主题</a>提供 - More Templates <a href="http://www.cssmoban.com/" target="_blank" title="模板之家">模板之家</a> - Collect from <a href="http://www.cssmoban.com/" title="网页模板" target="_blank">网页模板</a></span>
        </div></div>
</footer>
    <script type="text/javascript">
        // 百度地图API功能
        var map = new BMap.Map("allmap");
        var point = new BMap.Point(116.305458,40.046511);
        map.centerAndZoom(point, 15);
        var marker = new BMap.Marker(point);  // 创建标注
        map.addOverlay(marker);               // 将标注添加到地图中
        marker.setAnimation(BMAP_ANIMATION_BOUNCE); //跳动的动画
    </script>

</body>
</html>