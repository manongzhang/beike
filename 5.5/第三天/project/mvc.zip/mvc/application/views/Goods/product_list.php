﻿<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <title>制造工业</title>
    ﻿<meta charset="UTF-8">
    <base href="<?php echo __PUBLIC__;?>"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="format-detection" content="telephone=no">
<meta name="renderer" content="webkit">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="Cache-Control" content="no-siteapp" />
<link rel="alternate icon" type="image/png" href="images/favicon.png">
<link rel='icon' href='favicon.ico' type='image/x-ico' />
<meta name="description" content="" />
<meta name="keywords" content="" />
<link rel="stylesheet" href="css/default.min.css?t=227" />
<!--[if (gte IE 9)|!(IE)]><!-->
<script type="text/javascript" src="lib/jquery/jquery.min.js"></script>
<!--<![endif]-->
<!--[if lte IE 8 ]>
<script src="http://libs.baidu.com/jquery/1.11.3/jquery.min.js"></script>
<script src="http://cdn.staticfile.org/modernizr/2.8.3/modernizr.js"></script>
<script src="lib/amazeui/amazeui.ie8polyfill.min.js"></script>
<![endif]-->
<script type="text/javascript" src="lib/handlebars/handlebars.min.js"></script>
<script type="text/javascript" src="lib/iscroll/iscroll-probe.js"></script>
<script type="text/javascript" src="lib/amazeui/amazeui.min.js"></script>
<script type="text/javascript" src="lib/raty/jquery.raty.js"></script>
<script type="text/javascript" src="js/main.min.js?t=1"></script>
</head>
<body>
    <header class="header">
    <div class="header-container">
        <div class="header-div pull-left">
                <a class="header-logo">
                    <img src="images/logo.png" />
                </a>
            <button class="am-show-sm-only am-collapsed font f-btn" data-am-collapse="{target: '.header-nav'}">&#xe68b;</button>
        </div>
        

        <nav>
            <ul class="header-nav am-collapse">
                <?php foreach($nav['navData'] as $key => $val){?>
                    <li class="<?php if($nav['nav_id'] == $val['nav_order']){ echo 'on';}?>"><a href="<?php echo $val['nav_url'].'&nav_id='.$val['nav_order'];?>" class="nav"><?php echo $val['nav_name'];?></a></li>
                <?php }?>
            </ul>
            <div class="header-serch  am-hide-md-down">
                <input type="text" name="name" value="" />
                <em class="font">&#xe632;</em>
            </div>
        </nav>


    </div>
</header>
    <div class="com-banner">
        <img src="http://47.93.42.222/public/images/index_banner.jpg" />
    </div>
    <div class="com-container">
        <div class="cms-g">
            <div class="am-hide-sm-only am-u-md-3 am-u-lg-3">
                <div class="com-nav-left">
                    <h1><em>产品中心</em><i>PRODUCT</i></h1>
                    <ul>
                        <?php foreach($data['goodsData'] as $key => $val){?>
                            <li class="<?php if($data['goods_id'] == $val['goods_id']){echo 'on';}?>" goods_id="<?php echo $val['goods_id'];?>"><a href="<?php echo __URL__.'?act=goods/product_list&goods_id='.$val['goods_id'];?>"><?php echo $val['goods_name'];?></a></li>
                        <?php }?>
                    </ul>
                </div>
            </div>
            <div class="am-u-sm-12 am-u-md-9 am-u-lg-9">
                <div class="com-nav-title">
                    <a href="#doc-oc-demo1" class="font am-show-sm-only" data-am-offcanvas>&#xe68b;</a>
                    <span>LED灯具</span>
                </div>
                <div class="com-nav-category">
                    <ul>
                        <?php
                            if(empty($data['classData'])){
                                echo '还没有商品啊！亲';
                            }else{
                                foreach($data['classData'] as $key => $val){
                        ?>
                        <li class="<?php if($data['class_id'] == $val['class_id']){echo 'on';}?>"><span><a href="javascript:void(0);" class="classData" class_id="<?php echo $val['class_id'];?>"><?php echo $val['class_name'];?></a></span></li>
                        <?php }}?>
                    </ul>
                </div>
                <div class="product-list">
                    <?php
                    if(empty($data['productData'])){
                        echo '还没有商品啊！亲';
                    }else{
                        foreach($data['productData'] as $key => $val){
                    ?>
                            <div class="am-u-sm-6 am-u-md-4 am-u-lg-3">
                                <div class="product-list-item">
                                    <div class="product-list-item-bj">
                                        <a href="<?php echo __URL__."?act=goods/product_info&product_id=".$val['product_id']."&goods_id=".$data['goods_id'];?>"><img src="<?php echo $val['img_photo'];?>" /></a>
                                    </div>
                                    <div class="product-list-item-title">
                                        <a href="<?php echo __URL__."?act=goods/product_info&product_id=".$val['product_id']."&goods_id=".$data['goods_id'];?>" class="f-toe"><?php echo $val['product_name'];?></a>
                                    </div>
                                </div>
                            </div>
                    <?php }}?>
                </div>
                <div class="page-list">
                    <a href="javascript:void(0);" ajax="page" page="1"><<</a>
                    <a href="javascript:void(0);" ajax="page" page="<?php echo $data['page'] - 1 < 1? 1 : $data['page'] - 1;?>" id="prev"><</a>
                    <span id="a-page">
                        <?php for($i=1;$i<=$data['pageNum'];$i++){?>
                            <a href="javascript:void(0);" ajax="page" class="<?php if($i == $data['page']){echo 'on';}else{echo 'num';}?>" page="<?php echo $i;?>"><?php echo $i;?></a>
                        <?php }?>
                    </span>
                    <a href="javascript:void(0);" ajax="page" page="<?php echo $data['page'] + 1 > $data['pageNum']? $data['pageNum'] : $data['page'] + 1;?>" id="next">></a>
                    <a href="javascript:void(0);" ajax="page" page="<?php echo $data['pageNum'];?>">>></a>
                </div>
            </div>
        </div>
    </div>

    ﻿<footer>
    <div class="cms-g">
        <div class="footer">
            <ul>
                <li><a href="#"><span>网站地图</span></a></li>
                <li><a href="#"><span>访问统计</span></a></li>
                <li><a href="#"><span>友情链接</span></a></li>
                <li><a href="#"><span>法律申明</span></a></li>
            </ul>
            <span style="color:#fff;"><a href="http://www.haothemes.com/" target="_blank" title="好主题">好主题</a>提供 - More Templates <a href="http://www.cssmoban.com/" target="_blank" title="模板之家">模板之家</a> - Collect from <a href="http://www.cssmoban.com/" title="网页模板" target="_blank">网页模板</a></span>
        </div>   </div>
</footer>
</body>
</html>
<script>
    $(document).on('click','[ajax=page]',function(){
        var obj = $(this);
        var page = obj.attr('page');
        console.log(parseInt(page));
        var goods_id = $('.com-nav-left ul [class=on]').attr('goods_id');
        $('.page-list a').attr('class','num');
        var all_page = $('#a-page a');
        $.each(all_page,function(k,v){

            if(v.innerText == page){
                $(this).attr('class','on');
            }
        });
        var prev_page;
        if(parseInt(page)-1 < 1){
            prev_page = 1;
        }else{
            prev_page = parseInt(page)-1;
        }
        $('#prev').attr('page',prev_page);
        $('#next').attr('page',parseInt(page)+1);
        var class_id = $('.com-nav-category ul [class=on] span a').attr('class_id');
        $.ajax({
            url:'http://47.93.42.222/index.php?act=goods/productAjaxPage',
            type:'post',
            dataType:'json',
            data:{class_id:class_id,page:page},
            success:function(res){
                console.log(res);
                if(res.data.length == 0){
                    $('.product-list').html('没有商品了！亲');
                }else{
                    var str = '';
                    $.each(res.data,function(k,v){
                        str +='<div class="am-u-sm-6 am-u-md-4 am-u-lg-3">' +
                        '<div class="product-list-item">' +
                        '<div class="product-list-item-bj">' +
                        '<a href="index.php?act=goods/product_info&product_id='+ v.product_id+'&goods_id='+goods_id+'"><img src="'+ v.img_photo+'"/></a>' +
                        '</div>' +
                        '<div class="product-list-item-title">' +
                        '<a href="index.php?act=goods/product_info&product_id='+ v.product_id+'&goods_id='+goods_id+'" class="f-toe">'+ v.product_name+'</a>' +
                        '</div></div></div>';
                    });
                    $('.product-list').html(str);
                }

            }
        });
    });
    $('.classData').click(function(){
        var obj = $(this);
        var class_id = obj.attr('class_id');
        var goods_id = $('.com-nav-left ul [class=on]').attr('goods_id');
        $('.com-nav-category ul li').attr('class','');
        obj.parent().parent().attr('class','on');
        $.ajax({
            url:'http://47.93.42.222/index.php?act=goods/classData',
            type:'post',
            dataType:'json',
            data:{class_id:class_id},
            success:function(res){
                console.log(res);
                if(res.data.length == 0){
                    $('.product-list').html('还没有商品啊！亲');
                }else{
                    var str = '';
                    $.each(res.data,function(k,v){
                        str +='<div class="am-u-sm-6 am-u-md-4 am-u-lg-3"><div class="product-list-item"><div class="product-list-item-bj"><a href="<?php echo __URL__;?>?act=goods/product_info&product_id='+v.product_id+'&goods_id='+goods_id+'"><img src="'+v.img_photo+'" /></a></div><div class="product-list-item-title"><a href="./product_info.html" class="f-toe">'+v.product_name+'</a></div></div></div>';
                    });
                    $('.product-list').html(str);
                }

            }
        });
    });
</script>
