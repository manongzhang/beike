<?php
class navModel extends Model
{
    public $tableName = 'nav';

    public function getData()
    {
        $sql = "select * from nav order by nav_order";
        $data = $this->querySql($sql);
        return $data;
    }
}