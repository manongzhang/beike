<?php
class swiperModel extends Model
{
    public $tableName = 'swiper';

    public function getData()
    {
        $data = $this->selectRecord();
        return $data;
    }
}