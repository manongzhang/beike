<?php
class goodsModel extends Model
{
    public $tableName = 'goods';

    public function getData()
    {
        $data = $this->selectRecord();
        return $data;
    }

    public function getGoodsDesc($goods_id)
    {
        $sql = "SELECT * from details INNER JOIN details_desc on details.details_id = details_desc.details_id WHERE details.goods_id = '$goods_id'";
        $data = $this->querySql($sql);
        return $data;
    }

    public function getDefaultGoods_id()
    {
        $sql = "select goods_id from goods ORDER BY goods_id LIMIT 1";
        $data = $this->querySql($sql);
        return $data;
    }
}