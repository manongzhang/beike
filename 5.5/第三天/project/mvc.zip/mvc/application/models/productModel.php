<?php
class productModel extends Model
{
    public $tableName = 'product';

    public function getData($size,$page,$class_id)
    {
        $data = $this->page($size,$page,"class_id = '$class_id'");
        return $data;

    }

    public function detailsData($product_id)
    {
        $sql = "SELECT * from product INNER JOIN details on product.product_id = details.product_id INNER JOIN details_desc on details.details_id = details_desc.details_id WHERE product.product_id = '$product_id'";
        $data = $this->querySql($sql);
        return $data;
    }
}