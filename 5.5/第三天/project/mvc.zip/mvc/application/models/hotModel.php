<?php
class hotModel extends Model
{
//    public $tableName = 'about';

    public function getImgData()
    {
        $sql = "select hot_img.hot_img from hot_img INNER JOIN product on hot_img.product_id = product.product_id WHERE product.hot = 1";
        $data = $this->querySql($sql);
        return $data;
    }

    public function getDescData()
    {
        $sql = "select hot_desc.hot_desc from hot_desc INNER JOIN product on hot_desc.product_id = product.product_id WHERE product.hot = 1";
        $data = $this->querySql($sql);
        return $data;
    }
}