<?php
class apply_classModel extends Model
{
    public $tableName = 'apply_class';

    public function getData()
    {
        $data = $this->selectRecord();
        return $data;
    }

    public function getDataDesc($about_id)
    {
        $data = $this->findRecord("about_id = '$about_id'",'about_name,about_desc');
        return $data;
    }
}