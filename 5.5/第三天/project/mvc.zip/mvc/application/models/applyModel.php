<?php
class applyModel extends Model
{
    public $tableName = 'apply';

    public function getData()
    {
        $sql = "select * from apply limit 5";
        $data = $this->querySql($sql);
        return $data;
    }

    public function getClassData($apply_class_id)
    {
        $data = $this->selectRecord("class_id = '$apply_class_id'");
        return $data;
    }

    public function getContentData($apply_id){
        $data = $this->findRecord("apply_id = '$apply_id'",'class_id,apply_content');
        return $data;
    }
}