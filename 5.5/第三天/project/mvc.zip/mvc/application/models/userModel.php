<?php
class userModel extends Model
{
    public $tableName = 'users';

//    public function test()
//    {
//        $arr = [
//            'username' => '马六',
//            'password' => 19
//        ];
////        $where = [
////            'user_id' => 2,
////            'username' => '田七'
////        ];
//        $res = $this->selectRecord();
//        print_r($res);
//    }
//
//    public function select()
//    {
//        $sql = "select * from {$this->tableName}";
//        $res_obj = self::$pdo->query($sql);
//        $data = $res_obj->fetchAll(PDO::FETCH_ASSOC);
//        return $data;
//    }
//
//    public function uploads_add($fileName)
//    {
//        $sql = "insert into test (url) VALUES ('$fileName')";
//        self::$pdo->exec($sql);
//        $id = self::$pdo->lastInsertId();
//        return $id;
//    }
//
//    public function photo_list($page)
//    {
//        $size = 4;
//        $count_sql = "select count(1) from test";
//        $count_obj = self::$pdo->query($count_sql);
//        $count = $count_obj->fetchAll(PDO::FETCH_ASSOC);
//        $count = $count[0]['count(1)'];
//
//        $pageNum = ceil($count/$size);
//
//        $limit = ($page-1)*$size;
//
//        $sql = "select * from test limit $limit,$size";
//        $res_obj = self::$pdo->query($sql);
//        $data = $res_obj->fetchAll(PDO::FETCH_ASSOC);
//
//        $return_arr = [
//            'pageNum' => $pageNum,
//            'data' => $data,
//            'page' => $page
//        ];
//        return $return_arr;
//    }
//
//    public function photo_del($id)
//    {
//        $sql = "delete from test WHERE photo_id = '$id'";
//        $res = self::$pdo->exec($sql);
//        return $res;
//    }
//
//    public function get_photo_url($id)
//    {
//        $sql = "select url from test WHERE photo_id = '$id'";
//        $res_obj = self::$pdo->query($sql);
//        $data = $res_obj->fetchAll(PDO::FETCH_ASSOC);
//        return $data[0]['url'];
//    }
//
//    public function get_swiper()
//    {
//        $sql = "select * from test";
//        $res_obj = self::$pdo->query($sql);
//        $data = $res_obj->fetchAll(PDO::FETCH_ASSOC);
//        return $data;
//    }

    public function usernameOnly($username)
    {
        $data = $this->findRecord("username = '$username'");
        return $data;
    }

    public function addUser($arr)
    {
        $res = $this->createRecord($arr);
        return $res;
    }

    public function getData($where)
    {
        $data = $this->findRecord($where);
        return $data;
    }

    public function getTestData()
    {
        $sql = "select * from test WHERE is_del = 0";
        $data = $this->querySql($sql);
        return $data;
    }

    public function testDataDel($id)
    {
        $sql = "update test set is_del = 1 WHERE test_id = '$id'";
        $data = self::$pdo->exec($sql);
        return $data;
    }
}