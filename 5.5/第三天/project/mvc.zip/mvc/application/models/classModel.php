<?php
class classModel extends Model
{
    public $tableName = 'class';

    public function getData($goods_id)
    {
        $data = $this->selectRecord("goods_id = '$goods_id'");
        return $data;
    }
}