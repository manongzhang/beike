<?php
class newModel extends Model
{
    public $tableName = 'new';

    public function getData()
    {
        $sql = "select new_id,new_name,addtime from new limit 5";
        $data = $this->querySql($sql);
        return $data;
    }

    public function getClassData($new_class_id)
    {
        $data = $this->selectRecord("class_id = '$new_class_id'");
        return $data;
    }

    public function getOneData($new_id)
    {
        $data = $this->findRecord("new_id = '$new_id'",'class_id,new_content');
        return $data;
    }
}