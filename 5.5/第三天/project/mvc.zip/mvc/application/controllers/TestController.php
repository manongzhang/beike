<?php
class TestController extends Controller
{
    public function index()
    {
        $this->_view->display('index');
    }

    public function register()
    {
        $addArr['username'] = $_POST['username'];
        $addArr['password'] = $_POST['password'];
        if($_POST['password'] != $_POST['rePwd']){
            echo "<script>alert('两次密码不相同，请重新填写');</script>";
            $this->url('index.php?act=test/index');
            die;
        }
        $userObj = new userModel();
        $res = $userObj->addUser($addArr);
        if($res){
            echo "<script>alert('用户注册成功');</script>";
            $this->url('index.php?act=test/showLoginView');
        }else{
            echo "<script>alert('用户注册失败');</script>";
            $this->url('index.php?act=test/index');
        }
    }

    public function showLoginView()
    {
        $this->_view->display('login');
    }

    public function login()
    {
        $arr['username'] = $_POST['username'];
        $arr['password'] = $_POST['password'];
        session_start();
        $redis = new Redis();
        $redis->connect('127.0.0.1','6379');
        $redisErrorArr = $redis->get('error_num');
        $redisErrorArr = json_decode($redisErrorArr,true);

        $errorNum = [];
        foreach($redisErrorArr as $key => $val)
        {
            if($val['name'] == $arr['username']){
                $errorNum = $val;
                unset($redisErrorArr[$key]);
                break;
            }
        }

        if($errorNum['error_num'] >= 3){
            echo "<script>alert('当前用户已经登陆错误三次，请10分钟后再试');</script>";
            $this->url('index.php?act=test/showLoginView');
        }

        $userObj = new userModel();
        $res = $userObj->getData($arr);
        if($res){
            //登陆成功，记录登陆状态
            $redisStr = json_encode($res);
            $redis->setex(session_id(),1800,$redisStr);//记录30分钟的登陆状态
            $redis->setex($arr['username'],600,0); //设置有效期为10分钟的键值
            echo "<script>alert('登陆成功');</script>";
            $this->url('index.php?act=test/dataList');
        }else{
            if(empty($errorNum['error_num'])){
                $errorNum['error_num'] = 1;
                $errorNum['name'] = $arr['username'];
            }else{
                $errorNum['error_num'] = $errorNum['error_num'] + 1;
                $errorNum['name'] = $arr['username'];
            }
            $redisErrorArr[] = $errorNum;

            $redis->set('error_num',json_encode($redisErrorArr));
            echo "<script>alert('登陆失败');</script>";
            $this->url('index.php?act=test/showLoginView');
        }
    }

    public function dataDel()
    {
        $test_id = $_GET['test_id'];
        $userObj = new userModel();
        $res = $userObj->testDataDel($test_id);
        if($res){
            echo "<script>alert('删除成功');</script>";
            $this->url('index.php?act=test/dataList');
        }else{
            echo "<script>alert('删除成功');</script>";
            $this->url('index.php?act=test/dataList');
        }
    }

    public function dataList()
    {
        session_start();
        $redis = new Redis();
        $redis->connect('127.0.0.1','6379');
        $loginStatus = $redis->get(session_id());
        $loginStatus = json_decode($loginStatus,true);
        if($loginStatus == null){
            echo "<script>alert('您还没有登陆，请先登录');</script>";
            $this->url('index.php?act=test/showLoginView');
        }
        $userObj = new userModel();
        $data = $userObj->getTestData();
        $this->_view->assign('data',$data);
        $this->_view->display('list');
    }

    public function usernameOnly()
    {
        $username = $_POST['username'];
        $userObj = new userModel();
        $res = $userObj->usernameOnly($username);
        if(empty($res)){
            echo json_encode(1);
        }else{
            echo json_encode(0);
        }
    }

    public function clearLoginStatus()
    {
        session_start();
        $redis = new redis();
        $redis->connect('127.0.0.1', 6379);
        $redis->delete(session_id());
        echo "<script>alert('登陆状态已清除');</script>";
        $this->url('index.php?act=test/showLoginView');
    }
}