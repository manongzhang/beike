<?php
class BaseController extends Controller
{
    protected $nav_id;
    public function init()
    {
        $navObj = new navModel();
        $navData = $navObj->getData();
        if(empty($_GET['nav_id'])){
            $this->nav_id = $navData[0]['nav_order'];
        }else{
            $this->nav_id = $_GET['nav_id'];
        }
    }
}