<?php
class GoodsController extends Controller
{
    protected $nav_id;
    protected $navData;
    public function init()
    {
        $navObj = new navModel();
        $this->navData = $navObj->getData();
        if(empty($_GET['nav_id'])){
            $this->nav_id = $this->navData[0]['nav_order'];
        }else{
            $this->nav_id = $_GET['nav_id'];
        }
        $nav = [
            'navData' => $this->navData,
            'nav_id' => $this->nav_id,
        ];
        $this->_view->assign('nav', $nav);
    }

    public function index()
    {
        $swiperObj = new swiperModel();
        $swiperData = $swiperObj->getData();

        $hotObj = new hotModel();
        $imgData = $hotObj->getImgData();
        $descData = $hotObj->getDescData();

        $goodsObj = new goodsModel();
        $goodsData = $goodsObj->getData();

        $newObj = new newModel();
        $newData = $newObj->getData();

        $applyObj = new applyModel();
        $applyData = $applyObj->getData();


        $arr = [
            'imgData' => $imgData,
            'descData' => $descData,
            'goodsData' => $goodsData,
            'swiperData' => $swiperData,
            'newData' => $newData,
            'applyData' => $applyData,
        ];

        $this->_view->assign('data', $arr);
        $this->_view->display('index');
    }

    public function product_info()
    {
        $goods_id = $_GET['goods_id'];

        $product_id = $_GET['product_id'];

        $goodsObj = new goodsModel();
        $goodsData = $goodsObj->getData();

        $productObj = new productModel();
        $productDescData = $productObj->detailsData($product_id);

        $arr = [
            'productDescData' => $productDescData,
            'goodsData' => $goodsData,
            'goods_id' => $goods_id
        ];

        $this->_view->assign('data', $arr);
        $this->_view->display('product_info');
    }

    public function about()
    {
        $aboutObj = new aboutModel();
        $aboutData = $aboutObj->getData();

        $arr = [
            'aboutData' => $aboutData,
        ];
        $this->_view->assign('data', $arr);
        $this->_view->display('about');
    }

    public function aboutDesc()
    {
        $about_id = $_POST['about_id'];

        $aboutObj = new aboutModel();
        $aboutData = $aboutObj->getDataDesc($about_id);
        echo json_encode($aboutData);
    }

    public function product_list()
    {
        $page = empty($_GET['page']) ? 1 : $_GET['page'] ;
        $size = 4;

        $goodsObj = new goodsModel();
        $goodsData = $goodsObj->getData();

        if(empty($_GET['goods_id'])){
            $goods_id = $goodsData[0]['goods_id'];
        }else{
            $goods_id = $_GET['goods_id'];
        }

        $classObj = new classModel();
        $classData = $classObj->getData($goods_id);

        if(empty($_GET['class_id'])){
            if(empty($classData)){
                $productData = '';
                $class_id = 1;
            }else{
                $class_id = $classData[0]['class_id'];
                $productObj = new productModel();
                $productData = $productObj->getData($size,$page,$class_id);
            }
        }else{
            $class_id = $_GET['class_id'];
            $productObj = new productModel();
            $productData = $productObj->getData($size,$page,$class_id);
        }

        $arr = [
            'pageNum' => $productData['pageNum'],
            'goodsData' => $goodsData,
            'page' => $page,
            'productData' => $productData['data'],
            'classData' => $classData,
            'goods_id' => $goods_id,
            'class_id' => $class_id,
        ];
        $this->_view->assign('data', $arr);
        $this->_view->display('product_list');
    }

    public function productAjaxPage()
    {
        $page = empty($_POST['page']) ? 1 : $_POST['page'] ;
        $size = 4;
        $class_id = $_POST['class_id'];
        $productObj = new productModel();
        $productData = $productObj->getData($size,$page,$class_id);
        echo json_encode($productData);
    }

    public function classData()
    {
        $page = empty($_GET['page']) ? 1 : $_GET['page'] ;
        $size = 4;
        $class_id = $_POST['class_id'];
        $productObj = new productModel();
        $productData = $productObj->getData($size,$page,$class_id);
        echo json_encode($productData);
    }

    public function new_list()
    {
        $new_class_obj = new new_classModel();
        $new_class_data = $new_class_obj->getData();

        if(!empty($new_class_data)){
            $new_class_id = $new_class_data[0]['new_class_id'];
            $newObj = new newModel();
            $newData = $newObj->getClassData($new_class_id);
        }else{
            $new_class_id = 1;
            $newData = '';
        }

        $arr = [
            'newData' => $newData,
            'new_class_data' => $new_class_data,
            'new_class_id' => $new_class_id,
        ];
        $this->_view->assign('data', $arr);
        $this->_view->display('new_list');
    }

    public function new_info()
    {
        $new_id = $_POST['new_id'];
        $newObj = new newModel();
        $contentData = $newObj->getOneData($new_id);
        $contentData = $contentData['new_content'];
        echo json_encode($contentData);
    }

    public function indexNew()
    {
        $new_id = $_GET['new_id'];
        $newObj = new newModel();
        $contentData = $newObj->getOneData($new_id);
        $new_class_id = $contentData['class_id'];
        $contentData = $contentData['new_content'];

        $new_class_obj = new new_classModel();
        $new_class_data = $new_class_obj->getData();

        $arr = [
            'contentData' => $contentData,
            'new_class_data' => $new_class_data,
            'new_class_id' => $new_class_id,
            'new_id' => $new_id,
        ];

        $this->_view->assign('data', $arr);
        $this->_view->display('new_info');
    }

    public function indexApply()
    {
        $apply_id = $_GET['apply_id'];

        $applyObj = new applyModel();
        $contentData = $applyObj->getContentData($apply_id);

        $apply_class_id = $contentData['class_id'];
        $contentData = $contentData['apply_content'];

        $apply_class_obj = new apply_classModel();
        $apply_class_data = $apply_class_obj->getData();

        $arr = [
            'contentData' => $contentData,
            'apply_class_data' => $apply_class_data,
            'apply_class_id' => $apply_class_id,
            'apply_id' => $apply_id,
        ];

        $this->_view->assign('data', $arr);
        $this->_view->display('case_info');
    }

    public function getNewData()
    {
        $new_class_id = $_POST['new_class_id'];
        $newObj = new newModel();
        $newData = $newObj->getClassData($new_class_id);
        echo json_encode($newData);
    }

    public function case_list()
    {
        $apply_class_obj = new apply_classModel();
        $apply_class_data = $apply_class_obj->getData();

        if(!empty($apply_class_data)){
            $apply_class_id = $apply_class_data[0]['apply_class_id'];
            $applyObj = new applyModel();
            $applyData = $applyObj->getClassData($apply_class_id);
        }else{
            $apply_class_id = 1;
            $applyData = '';
        }

        $arr = [
            'applyData' => $applyData,
            'apply_class_id' => $apply_class_id,
            'apply_class_data' => $apply_class_data,
        ];


        $this->_view->assign('data', $arr);
        $this->_view->display('case_list');
    }

    public function case_info()
    {
        $apply_id = $_POST['apply_id'];
        $applyObj = new applyModel();
        $applyData = $applyObj->getContentData($apply_id);
        echo json_encode($applyData);

    }

    public function getApplyData()
    {
        $apply_class_id = $_POST['apply_class_id'];

        $applyObj = new applyModel();
        $applyData = $applyObj->getClassData($apply_class_id);
        echo json_encode($applyData);
    }

    public function contact()
    {
        $this->_view->display('contact');
    }
}