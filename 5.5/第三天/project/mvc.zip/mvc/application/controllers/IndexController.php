<?php
class IndexController extends Controller
{
    public function index()
    {
        $arr = [1,100,3,10,30,11,20];
        print_r($this->createTree($arr));
        die;

        $this->_view->display('test');
    }

    public function createTree($arr)
    {
        if(empty($arr[1])){
            return $arr;
        }
        $min = $arr[0];
        $leftArr = [];
        $rightArr = [];
        foreach($arr as $key => $val)
        {
            if($min > $val){
                $leftArr[] = $val;
            }elseif($min < $val){
                $rightArr[] = $val;
            }
        }
        $leftArr[] = $min;
        $leftArr = $this->createTree($leftArr);
        $rightArr = $this->createTree($rightArr);
        $returnArr = array_merge($leftArr,$rightArr);
        return $returnArr;
    }

    public function uploads()
    {
        $str = substr($_FILES['photo']['name'],strpos($_FILES['photo']['name'],'.'));
        $photoName = md5(uniqid(time().date('Y-m-d H:i:s'))).$str;
        $photoPath = '/mvc/uploads/'.$photoName;
        $res = move_uploaded_file($_FILES['photo']['tmp_name'],APP_PATH.'uploads/'.$photoName);
        if($res){
            $obj = new userModel();
            $id = $obj->uploads_add($photoPath);
            if($id){
                echo "<script>alert('文件上传成功');</script>";
                $this->url('index.php?act=index/photo_list');
            }else{
                echo "<script>alert('文件上传失败');</script>";
                $this->url('index.php?act=index/index');
            }
        }else{
            echo "<script>alert('文件上传失败');</script>";
            $this->url('index.php?act=index/index');
        }
    }

    public function photo_list()
    {
        $page = empty($_GET['page']) ? 1 : $_GET['page'] ;
        $obj = new userModel();
        $data = $obj->photo_list($page);
        $this->_view->assign('data',$data);
        $this->_view->display('photo_list');
    }

    public function photo_del()
    {
        $id = $_GET['id'];
        $obj = new userModel();
        $url = $obj->get_photo_url($id);
        $res = $obj->photo_del($id);
        if($res){
            unlink('/zhaoyang/'.$url);
            echo "<script>alert('图片删除成功');</script>";
            $this->url('index.php?act=index/photo_list');
        }else{
            echo "<script>alert('图片删除失败');</script>";
            $this->url('index.php?act=index/photo_list');
        }
    }

    public function swiper()
    {
        $obj = new userModel();
        $data = $obj->get_swiper();
        $this->_view->assign('data',$data);
        $this->_view->display('swiper');
    }

    /**快速排序
     * @param $arr
     * @return mixed
     */
    public function test($arr)
    {
        if(empty($arr[1])){
            return $arr;
        }

        $leftArr = [];
        $rightArr = [];
        $min = $arr[0];

        foreach($arr as $key => $val)
        {
            if($val['age'] < $min['age']){
                $leftArr[] = $val;
            }elseif($val['age'] > $min['age']){
                $rightArr[] = $val;
            }
        }

        $leftArr = $this->test($leftArr);
        $leftArr[] = $min;

        $rightArr = $this->test($rightArr);

        $allArr = array_merge($leftArr,$rightArr);

        print_r($allArr);
    }

    public function water()
    {
        $i = [];
        for($num=100;$num<=999;$num++)
        {
            $units = $num%10;
            $decade = $num/10%10;
            $hundreds = $num/100%10;
            if($units*$units*$units + $decade*$decade*$decade + $hundreds*$hundreds*$hundreds == $num){
                $i[] = $num;
            }
        }
        print_r($i);
    }
}