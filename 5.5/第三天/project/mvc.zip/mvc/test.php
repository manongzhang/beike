<?php
$redis = new Redis();
$redis->connect('127.0.0.1', 6379);
$redisErrorArr = $redis->get('error_num');
$redisErrorArr = json_decode($redisErrorArr,true);
$pdo = new PDO('mysql:host=47.93.42.222;dbname=goods','root','553548');
$values = '';
foreach($redisErrorArr as $key => $val)
{
    $values .= "('".$val['name']."',".$val['error_num']."),";
}
$values = trim($values,',');
$sql = "insert into error (username,error_num) VALUES $values";
$pdo->exec($sql);
$redis->delete('error_num');
?>