<?php
class Cookie
{
    /**
     * @param $name要设置的cookie的name
     * @param $val要设置的cookie的val
     */
    public function set($name,$val)
    {
        setcookie($name,$val);
    }

    /**
     * @param $name要获得cookie的name
     * @return mixed返回cookie中的结果
     */
    public function get($name)
    {
        $arr = $_COOKIE[$name];
        return $arr;
    }

    /**
     * @param $name要删除cookie中的name
     */
    public function del($name)
    {
        if(empty($name)){
            session_destroy();
        }else{
            unset($_COOKIE[$name]);
        }
    }

}