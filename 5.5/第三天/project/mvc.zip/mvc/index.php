<?php
//入口文件

//应用为当前目录
define('APP_PATH',__DIR__.'/');

//定义公告目录
define('__PUBLIC__','/public/');

//定义公告目录
define('__URL__','/index.php');

//开启调试模式
define('APP_DEBUG',false);

//加载配置文件
require('config/config.php');

//加载框架入口文件
require('vendor/fastphp.php');

$fast_obj = new fast($arr);
$fast_obj->run();
