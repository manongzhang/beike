<?php
$arr = [
    'db' => [
        'db_type' => 'mysql',
        'db_host' => '47.93.42.222',
        'db_name' => 'goods',
        'username' => 'root',
        'password' => '553548',
        'hostport' => '3306',
    ],
    //默认访问的控制器
    'default_controller' => 'Goods',
    //默认访问的方法
    'default_action' => 'index',
    'cache_time' => 300
];