<?php

namespace application\controllers;

use fastphp\base\Controller;
use application\models\PhpmyadminModel;

class PhpmyadminController extends Controller
{
	public function index()
	{
		session_start();
		if (empty($_SESSION['name'])) {
			echo "<script>alert('请登录！');location.href='/phpmyadmin/login';</script>";
			die;
		}
		$db = mysqli_connect("127.0.0.1", "root", "root");
		$sql = "show databases";
		$res = mysqli_query($db, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$databases[] = $result;
		}
		$this->assign("title", "phpMyadmin");
		$this->assign("databases", $databases);
		$this->assign("name", $_SESSION['name']);
		$this->render("index");
	}

	/**
	 * [create_database 数据库]
	 * @return [type] [description]
	 */
	public function create_database()
	{
		$create_dbname = $_POST['create_dbname'];
		$chat = $_POST['chat'];
		$order = $_POST['order'];
		$db = mysqli_connect("127.0.0.1", "root", "root");
		$sql = "create database $create_dbname";
		$res = mysqli_query($db, $sql);
		if ($res) {
			echo "1";
		} else {
			echo "2";
			die;
		}
	}

	/**
	 * [dbname_show 数据表]
	 * @return [type] [description]
	 */
	public function dbname_show()
	{
		$dbname = $_POST['dbname'];
		session_start();
		$_SESSION['dbname'] = $dbname;
		$db = mysqli_connect("127.0.0.1", "root", "root", $dbname);
		$sql = "show tables";
		$res = mysqli_query($db, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$tables[] = $result;
		}
		file_put_contents("./tabls.txt", json_encode($tables));
		echo json_encode($tables);
	}
	// 新建表
	public function add_table()
	{
		session_start();
		$dbname = $_SESSION['dbname'];
		$table_name = $_POST['table_name'];
		unset($_POST['dbname']);
		unset($_POST['table_name']);
		foreach ($_POST as $key => $val) {
			foreach ($val as $k => $v) {
				$arr[$k][$key] = $val[$k];
			}
		}
		$db = mysqli_connect("127.0.0.1", "root", "root", $dbname);
		$sql = "create table $table_name (";
		foreach ($arr as $key => $val) {
			if (isset($val['ifnull'])) {
				if (isset($val['primary'])) {
					$sql .= $arr[$key]['ziduan']." ".$arr[$key]['type']."(".$arr[$key]['changdu'].") not null primary key auto_increment,";
				} else {
					$sql .= $arr[$key]['ziduan']." ".$arr[$key]['type']."(".$arr[$key]['changdu'].") not null,";
				}
			}else {
				$sql .= $arr[$key]['ziduan']." ".$arr[$key]['type']."(".$arr[$key]['changdu']."),";
			}
		}
		$sql = trim($sql, ",");
		$sql .= ") ENGINE=InnoDB DEFAULT CHARSET=utf8";
		$res = mysqli_query($db, $sql);
		if ($res) {
			echo "<script>alert('数据表新建成功！');location.href='/phpmyadmin/index';</script>";
		} else {
			echo "<script>alert('数据表新建失败！');location.href='/phpmyadmin/index';</script>";
			die;
		}
	}
	// 展示数据表内容
	public function table_show()
	{
		$dbname = $_POST['dbname'];
		$tablename = $_POST['tablename'];
		$db = mysqli_connect("127.0.0.1", "root", "root", $dbname);
		$sql = "select * from $tablename";
		$res = mysqli_query($db, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$table_info[] = $result;
		}
		if (empty($table_info)) {
			echo "1";
			die;
		} else {
			echo json_encode($table_info);
		}
	}

	// 删除数据表
	public function deltable()
	{
		$dbname = $_POST['dbname'];
		$table_name = $_POST['table_name'];
		$db = mysqli_connect("127.0.0.1", "root", "root", $dbname);
		$sql = "drop table $table_name";
		$res = mysqli_query($db, $sql);
		if ($res) {
			echo "1";
		} else {
			echo "2";
			die;
		}
	}
	// 导出数据表
	public function dumptable()
	{
		$dbname = $_POST['dbname'];
		$table_name = $_POST['table_name'];
		$db = mysqli_connect("127.0.0.1", "root", "root", $dbname);
		$sql = "show create table $table_name";
		$res = mysqli_query($db, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$table_create_info = $result;
		}
		$file_path = "./application/views/phpmyadmin/dump_sql/".$dbname."/";
		$file_name = $table_name.".sql";
		$file = $file_path.$file_name;
		if (!is_dir($file_path)) {
			mkdir($file_path, 0777, true);
		}
		$time = date("Y-m-d H:i:s");
		$dump_top = "/*\r\nSource Server        : shujuku\r\nSource Host          : 127.0.0.1:3306\r\nSource Database      : $dbname\r\n\r\nTarget Server Type   : MYSQL\r\n\r\nDate: $time\r\n*/\r\n\r\n";
		$success = file_put_contents($file, $dump_top, FILE_APPEND);

		$dump_create = "-- -------------------------------------\r\n";
		$dump_create .= "-- Table structure for $table_name\r\n";
		$dump_create .= "-- -------------------------------------\r\n";
		$dump_create .= "DROP TABLE IF EXISTS `$table_name`;\r\n".$table_create_info['Create Table'].";\r\n\r\n";
		$success = file_put_contents($file, $dump_create, FILE_APPEND);

		$table_info = "-- ----------------------------\r\n";
		$table_info .= "-- Records of $table_name\r\n";
		$table_info .= "-- ----------------------------\r\n";
		$success = file_put_contents($file, $table_info, FILE_APPEND);

		$table_info_sql = "select * from $table_name";
		$table_info_res = mysqli_query($db, $table_info_sql);
		while ($table_info_result = mysqli_fetch_row($table_info_res)) {
			$str = "INSERT INTO ".$table_name." VALUES (";
			foreach ($table_info_result as $key => $val) {
				$str .= "'".$val."', ";
			}
			$str = substr($str, 0, strlen($str)-2);
			$str .= ");\r\n";
			$success = file_put_contents($file, $str, FILE_APPEND);
		}
		if ($success) {
			echo "1";
		} else {
			echo "2";
			die;
		}
	}
	// 导入数据表
	public function import()
	{
		session_start();
		$dbname = $_SESSION['dbname'];
		if (isset($_POST['file'])) {
			$sql = file_get_contents($_FILES['file']['tmp_name']);
		}
		$_FILES['file']['name'];
		$table_name = substr($_FILES['file']['name'], 0, strrpos($_FILES['file']['name'], "."));
		$db = mysqli_connect("127.0.0.1", "root", "root", $dbname);
		$arr = explode(";", $sql);
		foreach ($arr as $key => $val) {
			if (strrpos($val, $table_name)) {
				$res = mysqli_query($db, $val);
			}
		}
		if ($res) {
			echo "1";
		} else {
			echo "2";
			die;
		}
	}

	/**
	 * [login 登录]
	 * @return [type] [description]
	 */
	public function login()
	{
		$this->assign("title", "登录");
		$this->render("login");
	}
	public function login_do()
	{
		$name = trim($_POST['name']);
		$pwd = md5(md5(trim($_POST['pwd'])));
		$phpmyadminModel = new PhpmyadminModel;
		$res = $phpmyadminModel->where(["name = '$name'", "and pwd = '$pwd'"])->fetch();
		if ($res) {
			session_start();
			$_SESSION['name'] = $res['name'];
			echo "<script>alert('登录成功！');location.href='/phpmyadmin/index';</script>";
		} else {
			echo "<script>alert('登录失败！');location.href='/phpmyadmin/login';</script>";
			die;
		}
	}
	public function loginout()
	{
		session_start();
		if (!empty($_SESSION['name'])) {
			session_unset();
			echo "<script>alert('退出成功！');location.href='/phpmyadmin/login';</script>";
			die;
		}
	}
}