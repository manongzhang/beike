<?php

namespace application\controllers;

use fastphp\base\Controller;

/**
* 
*/
class WelcomeController extends Controller
{
	
	public function index()
	{
		echo "<h2>欢迎使用我的第一个框架</h2>";
	}
}