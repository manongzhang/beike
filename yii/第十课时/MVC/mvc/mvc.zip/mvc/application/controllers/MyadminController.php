<?php

namespace application\controllers;

use fastphp\base\Controller;
use application\models\PhpmyadminModel;

/**
 * 
 */
class MyadminController extends Controller
{
	// 数据库
	public function database_list()
	{
		$db = mysqli_connect("127.0.0.1", "root", "root");
		$sql = "show databases";
		$res = mysqli_query($db, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$databases[] = $result;
		}
		$this->assign("databases", $databases);
		$this->render("database_list");
	}
	public function create_database()
	{
		$create_dbname = $_POST['create_dbname'];
		$chat = $_POST['chat'];
		$order = $_POST['order'];
		$db = mysqli_connect("127.0.0.1", "root", "root");
		$sql = "create database $create_dbname";
		$res = mysqli_query($db, $sql);
		if ($res) {
			echo "1";
		} else {
			echo "2";
			die;
		}
	}
	// 展示数据表
	public function table_list()
	{
		$dbname = $_POST['dbname'];
		$db = mysqli_connect("127.0.0.1", "root", "root", $dbname);
		$sql = "show tables";
		$res = mysqli_query($db, $sql);
		while ($result = mysqli_fetch_assoc($res)) {
			$tables[] = $result;
		}
		echo json_encode($tables);
	}
	public function add_table()
	{
		var_dump($_POST);
	}
	// public function add_table()
	// {
	// 	$this->render("add_table");
	// }
}