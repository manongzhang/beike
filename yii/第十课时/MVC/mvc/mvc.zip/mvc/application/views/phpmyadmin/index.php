<style type="text/css">
	a:link {
		text-decoration: none;
		color: #000;
	}
	.top {
		width: 1500px;
		height: 50px;
	}
	.top_left {
		float: left;
	}
	.top_right {
		float: right;
	}
	.bottom {
		float: left;
		width: 1500px;
		height: 650px;
	}
	.bottom_left {
		float: left;
		width: 200px;
		height: 600px;
		margin-top: 30px;
		margin-left: 20px;
		margin-right: 50px;
	}
	.bottom_left_top {
		float: left;
		height: 30px;
	}
	.bottom_left_bottom {
		float: left;
		width: 200px;
		height: 300px;
		overflow: auto;
	}
	.bottom_right {
		float: left;
		/*width: 1230px;*/
	}
	.bottom_right_top {
		width: 600px;
		margin-top: 30px;
		margin-bottom: 10px;
		font-weight: bold;
	}
	.bottom_right_bottom {
		width: 600px;
		height: 450px;
		padding-right: 10px;
		overflow: auto;
	}
</style>
<?php
	$db = mysqli_connect("127.0.0.1", "root", "root");
	$sql = "SHOW CHARACTER SET";
	$res = mysqli_query($db, $sql);
	while ($result = mysqli_fetch_assoc($res)) {
		$character[] = $result;
	}
	$sql_o = "show variables like 'collation%'";
	$res_o = mysqli_query($db, $sql_o);
	while ($result = mysqli_fetch_assoc($res_o)) {
		$variables[] = $result;
	}
?>
<div class="top">
	<div class="top_left">
		<h2>PhpMyadmin</h2>
	</div>
	<div class="top_right">
		<h2>
			用户：
			<?php
				echo $_SESSION['name'];
			?> |
			<a href="/phpmyadmin/loginout">退出</a>			
		</h2>
	</div>
</div>
<div class="bottom">
	<div class="bottom_left">
		<div class="bottom_left_top" style="">
			<b id="hide">数据库：</b>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<button id="create_database">新建库</button>
		</div>
		<div class="bottom_left_bottom" style="overflow: auto;">
			<?php foreach ($databases as $key => $val) { ?>
				<p>
					<a href="javascript:;" id="databaseslist"><?= $val['Database']; ?></a>
				</p>
			<?php } ?>
		</div>
	</div>
	<div class="bottom_right">
		<div id="create_database_show" style="display: none; width: 500px;">
			<h3>新建数据库</h3>
			<table>
				<tr>
					<th>数据库名称：</th>
					<td><input type="text" name="dbname" id="dbname" /></td>
				</tr>
				<tr>
					<th>字符集：</th>
					<td>
						<select name="chat" id="chat">
							<option>请选择字符集</option>
							<?php foreach ($character as $key => $val) { ?>
								<option value="<?= $val['Default collation']?>">
									<?= $val['Default collation']?>	
								</option>
							<?php } ?>
						</select>
					</td>
				</tr>
				<tr>
					<th>排序规则：</th>
					<td>
						<select name="order" id="order" value="">
							<option>请选择排序规则</option>
							<?php foreach ($variables as $key => $val) { ?>
								<option value="<?= $val['Value']?>">
									<?= $val['Value']?>
								</option>
							<?php } ?>
						</select>
					</td>
				</tr>
				<tr>
					<th></th>
					<td><input type="submit" id="add_database" value="提交"></td>
				</tr>
			</table>
		</div>
		<div class="bottom_right_top" style="display: none;">
			<a href="javascript:;">打开表</a>&nbsp;&nbsp;
			<a href="javascript:;">设计表</a>&nbsp;&nbsp;
			<a href="javascript:;">新建表</a>&nbsp;&nbsp;
			<a href="javascript:;">删除表</a>&nbsp;&nbsp;
			<a href="javascript:;">导入表</a>
			<input type="file" id="file">
		</div>
		<div class="create_tables" style="display: none; width: 800px;">
			<form action="/phpmyadmin/add_table" method="post">
				<input type="hidden" name="dbname" value="">
				<h3>新建数据表</h3>
				<table>
					<tr>
						<th>表名</th>
						<td colspan="7">
							<input type="text" name="table_name" id="table_name" style="width: 200px;">
						</td>
					</tr>
					<tr>
						<th>字段</th><th>类型</th><th>长度</th><th>是否为空</th><th>主键</th><th>默认值</th><th>注释</th><th>操作</th>
					</tr>
					<tr>
						<td><input type="text" id="ziduan" name="ziduan[]" style="width: 80px;"></td>
						<td>
							<select id="type" name="type[]">
								<option>请选择字段类型</option>
								<option>tinyint</option>
								<option>int</option>
								<option>char</option>
								<option>varchar</option>
								<option>datetime</option>
							</select>
						</td>
						<td><input type="text" id="changdu" name="changdu[]" style="width: 80px;"></td>
						<td><input type="checkbox" value="1" id="ifnull" name="ifnull[]" style="width: 80px;"></td>
						<td><input type="checkbox" value="1" id="primary" name="primary[]" style="width: 80px;"></td>
						<td><input type="text" id="moren" name="moren[]" style="width: 80px;"></td>
						<td><input type="text" id="zhushi" name="zhushi[]" style="width: 80px;"></td>
						<td><b id="jia">+</b>&nbsp;&nbsp;&nbsp;<b id="jian">-</b></td>
					</tr>
					<tr>
						<td coltd="8"><input type="submit" id="create_table" value="新建"></span>
					</tr>
				</table>
			</form>
		</div>
		<div class="bottom_right_bottom">
		</div>
	</div>
</div>
<script src="../jquery-3.2.1.js"></script>
<script type="text/javascript">
	var dbname
	// 数据表列表
	$(document).ready(function() {
		$(document).on("click", "#databaseslist", function() {
			$("#create_database_show").hide()
			$(".create_tables").hide()
			$(".bottom_right_top").show()
			dbname = $(this).text()
			$.ajax({
				dataType:"json",
				type:"post",
				data:"dbname="+dbname,
				url :"/phpmyadmin/dbname_show",
				success:function(msg) {
					var html = '<h4>数据库：'+dbname+'</h4>'
					for (var i = 0; i < msg.length; i++) {
						html += '<p><span><a href="javascript:;" id="tableslist" dbname="'+dbname+'">'+msg[i]['Tables_in_'+dbname+'']+'</a></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="float: right;"><a href="javascript:;" id="deltable" table_name="'+msg[i]['Tables_in_'+dbname+'']+'">删除</a>&nbsp;|&nbsp;<a href="javascript:;" id="deltable" table_name="'+msg[i]['Tables_in_'+dbname+'']+'">修改</a>&nbsp;|&nbsp;<a href="javascript:;" id="dumptable" table_name="'+msg[i]['Tables_in_'+dbname+'']+'">导出</a></span></p>'
					}
					$(".bottom_right_bottom").html(html)
				}
			})
		})
		// 新建数据库
		$(document).on("click", "#create_database", function() {
			$(".bottom_right_top").hide()
			$(".bottom_right_bottom").hide()
			$("#create_database_show").show()
		})
		$(document).on("click", "#add_database", function() {
			var create_dbname = $("#dbname").val()
			var chat = $("#chat").val()
			var order = $("#order").val()
			$.ajax({
				type:"post",
				data:"create_dbname="+create_dbname+"&chat="+chat+"&order="+order,
				url :"/phpmyadmin/create_database",
				success:function(msg) {
					if (msg == "1") {
						alert("数据库新建成功！")
						window.location.href = "/phpmyadmin/index"
					} else if (msg == "2") {
						alert("数据库新建失败！")
						window.location.href = "/phpmyadmin/index"
					}
				}
			})
		})

		// 新建表
		$(document).on("click", ".bottom_right_top a:eq(2)", function() {
			$(".create_tables").show()
			$(".bottom_right_bottom").hide()
		})
		num = 0
		$(document).on("click", "#jia", function() {
			var html = ''
			html += '<tr>'
					+'<td><input type="text" id="ziduan" name="ziduan[]" style="width: 80px;"></td>'
					+'<td>'
						+'<select id="type" name="type[]">'
							+'<option>请选择字段类型</option>'
							+'<option>tinyint</option>'
							+'<option>int</option>'
							+'<option>char</option>'
							+'<option>varchar</option>'
							+'<option>datetime</option>'
						+'</select>'
					+'</td>'
					+'<td><input type="text" id="changdu" name="changdu[]" style="width: 80px;"></td>'
					+'<td><input type="checkbox" value="1" id="ifnull" name="ifnull[]" style="width: 80px;"></td>'
				 +'<td><input type="checkbox" value="1" id="primary" name="primary[]" style="width: 80px;"></td>'
					+'<td><input type="text" id="moren" name="moren[]" style="width: 80px;"></td>'
					+'<td><input type="text" id="zhushi" name="zhushi[]" style="width: 80px;"></td>'
					+'<td><b id="jia">+</b>&nbsp;&nbsp;&nbsp;<b id="jian">-</b></td>'
					+'</tr>'
			$(".create_tables tr:eq(2)").after(html)
			num++
		})
		$(document).on("click", "#jian", function() {
			if (num > 0) {
				$(".create_tables tr:eq(2)").remove()
				num--
			}			
		})
		// 数据表的内容展示
		$(document).on("dblclick", "#tableslist", function() {
			var tablename = $(this).text()
			$.ajax({
				type:"post",
				data:"dbname="+dbname+"&tablename="+tablename,
				url :"/phpmyadmin/table_show",
				success:function(msg) {
					if (msg == "1") {
						alert("此表为空！")
						return
					} else {
						var str1 = ''
						var str555 = '<tr>'
						var str = '<table border="1">'
						var arr = JSON.parse(msg)
						for (ccc in arr[0]) {
							str += "<th>"+ccc+"</th>"
						}
						for (aaa in arr) {
							$(arr[aaa]).each(function(k,v) {
								for (lll in v) {
									str555 += "<td>"+v[lll]+"</td>"
								};
								str555 += "</tr>"
							})
						};
						str2 = str+str555+"</table>";
						$(".bottom_right_bottom").html(str2)
					}
				}
			})
		})
		// 删除表
		$(document).on("click", "#deltable", function() {
			var table_name = $(this).attr("table_name")
			$.ajax({
				type:"post",
				data:"dbname="+dbname+"&table_name="+table_name,
				url :"/phpmyadmin/deltable",
				success:function(msg) {
					if (msg == "1") {
						alert("数据表删除成功！")
						window.location.href = "/phpmyadmin/index"
					} else if (msg == "2") {
						alert("数据表删除失败！")
					}
				}
			})
		})
		// 导出表
		$(document).on("click", "#dumptable", function() {
			var table_name = $(this).attr("table_name")
			$.ajax({
				type:"post",
				data:"dbname="+dbname+"&table_name="+table_name,
				url :"/phpmyadmin/dumptable",
				success:function(msg) {
					if (msg == "1") {
						alert("数据表导出成功！")
						window.location.href = "/phpmyadmin/index"
					} else if (msg == "2") {
						alert("数据表导出失败！")
					}
				}
			})
		})
		// 导入表
		$(document).on("click", ".bottom_right_top a:eq(4)", function() {
			var file = $("#file").val()
			var formdata = new FormData()
			formdata.append("file", file)
			formdata.append("file", $("#file").get(0).files[0])
			$.ajax({
				type:"post",
				data:formdata,
				url :"/phpmyadmin/import",
				contentType: false,
				processData: false,
				success:function(msg) {
					if (msg == "1") {
						alert("数据表导入成功！")
						window.location.href = "/phpmyadmin/index"
					} else if (msg == "2") {
						alert("数据库导入失败！")
					}
				}
			})
		})
		$(document).on("click", "#hide", function() {
			$(".bottom_right").hide()
		})
	})
</script>