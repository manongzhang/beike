<form action="/phpmyadmin/login_do" method="post">
	<table>
		<tr>
			<th>用户名：</th>
			<td><input type="text" name="name"></td>
		</tr>
		<tr>
			<th>密码：</th>
			<td><input type="password" name="pwd"></td>
		</tr>
		<tr>
			<th></th>
			<td><input type="submit" value="登录"></td>
		</tr>
	</table>
</form>