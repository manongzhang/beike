/*
Source Server        : shujuku
Source Host          : 127.0.0.1:3306
Source Database      : blog

Target Server Type   : MYSQL

Date: 2017-12-28 05:49:50
*/

-- -------------------------------------
-- Table structure for blog_cart
-- -------------------------------------
DROP TABLE IF EXISTS `blog_cart`;
CREATE TABLE `blog_cart` (
  `cart_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cart_name` varchar(100) DEFAULT NULL,
  `display` int(1) DEFAULT '0' COMMENT '0=显示，1=不显示',
  `sort` int(1) DEFAULT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of blog_cart
-- ----------------------------
INSERT INTO blog_cart VALUES ('1', '休闲', '0', '11');
INSERT INTO blog_cart VALUES ('2', '旅游', '0', '11');
INSERT INTO blog_cart VALUES ('3', '网络', '0', '11');
INSERT INTO blog_cart VALUES ('4', '社交', '0', '11');
INSERT INTO blog_cart VALUES ('5', '摄影', '0', '11');
