<meta charset="utf8">

<style>
table{ border-collapse: collapse; border: 1px solid #ddd; width: 500px; margin: 0 auto;margin-top: 50px; background: rgba(121, 217, 221, 0.4); color: #666}
table tr{ height: 40px;}
table td{ border: 1px solid #ddd; text-align: center}
table .title{ background: rgba(14, 196, 210, 0.99); color: #fff}

*{ margin: 0; padding:0 ; font-family: 微软雅黑}
a{ text-decoration: none; color: #666;}
ul{ list-style: none}

.top{ width: 100%; background: rgba(14, 196, 210, 0.99); color: #fff; height: 50px; line-height: 80px; text-align: right;}
.top span{ margin-right: 20px}


.left{ width: 260px; float: left; height: 100%; background: rgba(121, 217, 221, 0.4)}
.left ul{ list-style: none; width: 100%;}
.left ul li{ height: 40px; width: 100%; border: 1px solid #ddd; line-height: 40px; text-align: center;}
.left .selected{ background: rgba(14, 196, 210, 0.99);}
.left .selected a{ color: #fff;}


.right{ float: left; width: 1000px;}
.search-box{ width: 900px; margin: 0 auto; margin-top: 100px; }
.right li{
    margin-top: 20px;
}
.right span{
    display: inline-block;
    width: 200px;
    line-height: 40px;
    height: 40px;
    text-align: right;
    margin-right: 20px;
}

.right .table-list{
    margin-top: 20px; 
}

.right .table-list .table-input{
    width: 300px;
    line-height: 40px;
    height: 40px;
    border: 1px solid #ddd;
    border-radius: 3px;
    font-size: 14px;
    padding-left: 8px;
    margin-left: 10px;
}

.right .table-list select{
    margin-left: 10px;
    margin-top: 20px;
}

.right .filed-list{
    font-size: 14px;
    margin-top: 20px;
    margin-left: 20px;
}

.right .filed-list .select{
    margin: 0 5px;
}

.right .filed-list .input-text{
    width: 150px;
    height: 30px;
    border: 1px solid #ddd;
    border-radius: 5px;
    margin: 5px;
}

.right .handdle a{
    background: rgba(14, 196, 210, 0.99);
    color: #fff;
    font-size: 14px;
    width: 130px;
    height: 30px;
    line-height: 30px;
    border-radius: 3px;
    border: 1px solid #ddd;
    display: inline-block;
    background: rgba(14, 196, 210, 0.99);
    color: #fff;
    text-align: center;
    margin-left: 20px;
    margin-top: 20px;
}

.submit{
    width: 150px;
    height: 35px;
    line-height: 35px;
    border-radius: 3px;
    border: 1px solid #ddd;
    display: inline-block;
    background: rgba(14, 196, 210, 0.99);
    color: #fff;
    text-align: center;
    margin: 5px auto;
}
</style>
<?php
	$db = mysqli_connect("127.0.0.1", "root", "root");
	$sql = "SHOW CHARACTER SET";
	$res = mysqli_query($db, $sql);
	while ($result = mysqli_fetch_assoc($res)) {
		$character[] = $result;
	}
	$sql_o = "show variables like 'collation%'";
	$res_o = mysqli_query($db, $sql_o);
	while ($result = mysqli_fetch_assoc($res_o)) {
		$variables[] = $result;
	}
?>
<div class="top">
	<span>欢迎管理员：admin</span>
</div>

<div class="left">
	<ul>
		<li><a href="javascript:;" id="create_db" style="font-weight: 900;">添加新数据库</a></li>
		<?php foreach ($databases as $key => $val) { ?>
			<li class="selected"><a href="javascript:;" id="showtables"><?= $val['Database']; ?></a></li>
		<?php } ?>
	</ul>
</div>

<div class="right">
	<div class="database-box" style="display: none;">
		<table class="filed-list">
			<tr>
				<th>数据库名称：</th>
				<td>
					<input type="text" class="input-text" id="create_dbname">
				</td>
			</tr>
			<tr>
				<th>字符集：</th>
				<td>
					<select name="" id="chat">
						<option value="">请选择字符集</option>
						<?php foreach ($character as $key => $val) { ?>
							<option value="<?= $val['Default collation']?>">
								<?= $val['Default collation']?>	
							</option>
						<?php } ?>
					</select>
				</td>
			</tr>
			<tr>
				<th>排序规则：</th>
				<td>
					<select name="" id="order">
						<option value="">请选择排序规则</option>
						<?php foreach ($variables as $key => $val) { ?>
							<option value="<?= $val['Value']?>">
								<?= $val['Value']?>
							</option>
						<?php } ?>
					</select>
				</td>
			</tr>
			<tr>
				<td colspan="8">
					<a href="javascript:;" class="submit" id="add_database">提交</a>
				</td>
			</tr>
		</table>
	</div>
	<div class="tables-box">
		<div id="tables-list" style="display: none;">
			<table id="tt" style="overflow: auto; height: 10px;">
				<tr class="title">
					<td>库名：</td>
					<td><a href="javascript:;">查看注册字段</a></td>
					<td><a href="javascript:;">查看注册字段</a></td>
					<td><a href="javascript:;" id="create_table">添加新表</a></td>
				</tr>
				<tr>
					<td>user</td>
				</tr>
			</table>
		</div>
		<div id="create-tables" style="display: none;">
			<form action="/myadmin/add_table" method="post">
				<h4>请填写表信息</h4>
				<div class="table-list">
					<input type="text" id="tablename" class="table-input" name="tablename" placeholder="请输入表名">
					<input type="text" class="table-input" name="tablezhushi" placeholder="请输入表注释">
					<br>
					<select name="yinqing" id="yinqing">
						<option value="">请选择表引擎</option>
						<option value="MyISAM">MyISAM</option>
						<option value="InnoDB">InnoDB</option>
					</select>
					<select name="zforder" id="zforder">
						<option value="">请选择字符排序规则</option>
						<option value="utf8-general-ci">utf8-general-ci</option>
						<option value="GBK2313">GBK2313</option>
					</select>
				</div>
				<h4 style="margin-top: 40px;">请填写字段信息</h4>
				<p class="handdle">
					<a href="javascript:;" id="jia">追加行</a>
					<a href="javascript:;">在选中行之后插入</a>
					<a href="javascript:;" id="jian">删除选中行</a>
				</p>
				<table class="filed-list">
					<tr class="title">
						<td>操作</td>
						<td>字段名</td>
						<td>字段类型</td>
						<td>字段长度</td>
						<td>索引</td>
						<td style="width:80px;">是否自增</td>
						<td>默认值</td>
						<td>注释</td>
					</tr>
					<tr id="show">
						<td style="width: 50px;">
							<b id="del"> - </b>
						</td> 
						<td>
							<input type="text" class="input-text" id="ziduan" name="ziduan[]">
						</td>
						<td class="options">
							<select name="type[]" id="type">
								<option value="">请选择字段类型</option>
								<option value="int">int</option>
								<option value="char">char</option>
								<option value="varchar">varchar</option>
								<option value="text">text</option>
								<option value="datetime">datetime</option>
							</select>
						</td>
						<td>
							<input type="text" class="input-text" id="changdu" name="changdu[]">
						</td>
						<td>
							<select name="index[]" id="index">
								<option value="">请选择索引</option>
								<option value="primary">primary</option>
								<option value="index">index</option>
								<option value="unique">unique</option>
							</select>
						</td>
						<td>
							<input type="checkbox" value="" class="input-checkbox" id="zizeng" name="zizeng[]">
						</td>
						<td>
							<input type="text" class="input-text" id="moren" name="moren[]">
						</td>
						<td>
							<input type="text" class="input-text" id="zhushi" name="zhushi[]">
						</td>
					</tr>
					<tr class="last">
						<td colspan="8">
							<input type="submit" class="submit" value="提交">
							<!-- <a href="javascript:;" class="submit" id="add_table">提交</a> -->
						</td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>
<script src="../jquery-3.2.1.js"></script>
<script type="text/javascript">
	var dbname
	$(document).ready(function() {
		// 数据库
		$(document).on("click", "#create_db", function() {
			$(".database-box").show()
		})
		$(document).on("click", "#add_database", function() {
			var create_dbname = $("#create_dbname").val()
			var chat = $("#chat").val()
			var order = $("#order").val()
			$.ajax({
				type:"post",
				data:"create_dbname="+create_dbname+"&chat="+chat+"&order="+order,
				url :"/myadmin/create_database",
				success:function(msg) {
					if (msg == "1") {
						alert("数据库新建成功！")
						window.location.href = "/myadmin/database_list"
					} else if (msg == "2") {
						alert("数据库新建失败！")
						window.location.href = "/myadmin/database_list"
					}
				}
			})
		})
		// 数据表
		$(document).on("dblclick", "#showtables", function() {
			$("#tables-list").show()
			$("#create-tables").hide()
			dbname = $(this).text()
			$.ajax({
				dataType:"json",
				type:"post",
				data:"dbname="+dbname,
				url :"/myadmin/table_list",
				success:function(msg) {
					var html = ''
					html += '<tr class="title">'
								+'<td>库名：'+dbname+'</td>'
								+'<td><a href="javascript:;">查看注册字段</a></td>'
								+'<td><a href="javascript:;">查看注册字段</a></td>'
								+'<td><a href="javascript:;" id="create_table">添加新表</a></td>'
							+'</tr>'
					for (var i = 0; i < msg.length; i++) {
						html += '<tr>'
									+'<td colspan="4">'+msg[i]['Tables_in_'+dbname+'']+'</td>'
								+'</tr>'
					}
					$("#tt").html(html)
				}
			})
		})
		// 数据表
		$(document).on("click", "#create_table", function() {
			$("#tables-list").hide()
			$("#create-tables").show()
		})
		num = 0
		$(document).on("click", "#jia", function() {
			var html = ''
			html += '<tr>'
						+'<td style="width: 50px;">'
							+'<b id="del"> - </b>'
						+'</td>' 
						+'<td>'
							+'<input type="text" class="input-text">'
						+'</td>'
						+'<td class="options">'
							+'<select name="" id="">'
								+'<option value="">请选择字段类型</option>'
								+'<option value="">int</option>'
								+'<option value="">char</option>'
								+'<option value="">varchar</option>'
								+'<option value="">text</option>'
								+'<option value="">datetime</option>'
							+'</select>'
						+'</td>'
						+'<td>'
							+'<input type="text" class="input-text">'
						+'</td>'
						+'<td>'
							+'<select name="" id="">'
								+'<option value="">请选择索引</option>'
								+'<option value="">primary</option>'
								+'<option value="">index</option>'
								+'<option value="">unique</option>'
							+'</select>'
						+'</td>'
						+'<td>'
							+'<input type="checkbox" value="" class="input-checkbox">'
						+'</td>'
						+'<td>'
							+'<input type="text" class="input-text">'
						+'</td>'
						+'<td>'
							+'<input type="text" class="input-text">'
						+'</td>'
					+'</tr>'
			num = num + 1
			$(".last").before(html);
		})
		$(document).on("click", "#del", function() {
			if (num > 0) {
				$(this).parent().parent().remove()
				num = num - 1
			}
		})
		// 创建表
		// $(document).on("click", "#add_table", function() {
		// 	var ziduan = $("#ziduan").val()
		// 	var type = $("#type").val()
		// 	var changdu = $("#changdu").val()
		// 	var index = $("#index").val()
		// 	var zizeng = $("#zizeng").is(":checked")
		// 	var moren = $("#moren").val()
		// 	var zhushi = $("#zhushi").val()
		// 	$.ajax({
		// 		type:"post",
		// 		data:"ziduan="+ziduan+"&type="+type+"&changdu="+changdu+"&index="+index+"&zizeng="+zizeng+"&moren="+moren+"&zhushi="+zhushi,
		// 		url :"/myadmin/add_table",
		// 		success:function(msg) {
		// 			alert(msg)
		// 			if (msg == "1") {
		// 				alert("数据表新建成功！")
		// 				window.location.href = "/myadmin/database_list"
		// 			} else if (msg == "2") {
		// 				alert("数据表新建失败！")
		// 			}
		// 		}
		// 	})
		// })
	})
</script>