<meta charset="utf8">

<style>
table{ border-collapse: collapse; border: 1px solid #ddd; width: 960px; margin: 0 auto;margin-top: 50px; background: rgba(121, 217, 221, 0.4); color: #666}
table tr{ height: 40px;}
table td{ border: 1px solid #ddd; text-align: center}
table .title{ background: rgba(14, 196, 210, 0.99); color: #fff}

*{margin: 0; padding:0 ; font-family: 微软雅黑}
a{ text-decoration: none; color: #666;}
ul{ list-style: none}

.top{ width: 100%; background: rgba(14, 196, 210, 0.99); color: #fff; height: 100px; line-height: 150px; text-align: right;}
.top span{ margin-right: 20px}


.left{ width: 260px; float: left; height: 100%; background: rgba(121, 217, 221, 0.4)}
.left ul{ list-style: none; width: 100%;}
.left ul li{ height: 40px; width: 100%; border: 1px solid #ddd; line-height: 40px; text-align: center;}
.left .selected{ background: rgba(14, 196, 210, 0.99);}
.left .selected a{ color: #fff;}


.right{ float: left; width: 1000px;}
.search-box{ width: 900px; margin: 0 auto; margin-top: 100px; }
.right li{
    margin-top: 20px;
}
.right span{
    display: inline-block;
    width: 200px;
    line-height: 40px;
    height: 40px;
    text-align: right;
    margin-right: 20px;
}

.right .table-list{
    margin-top: 20px; 
}

.right .table-list .table-input{
    width: 300px;
    line-height: 40px;
    height: 40px;
    border: 1px solid #ddd;
    border-radius: 3px;
    font-size: 14px;
    padding-left: 8px;
    margin-left: 10px;
}

.right .table-list select{
    margin-left: 10px;
    margin-top: 20px;
}

.right .filed-list{
    font-size: 14px;
    margin-top: 20px;
    margin-left: 20px;
}

.right .filed-list .select{
    margin: 0 5px;
}

.right .filed-list .input-text{
    width: 150px;
    height: 30px;
    border: 1px solid #ddd;
    border-radius: 5px;
    margin: 5px;
}

.right .handdle a{
    background: rgba(14, 196, 210, 0.99);
    color: #fff;
    font-size: 14px;
    width: 130px;
    height: 30px;
    line-height: 30px;
    border-radius: 3px;
    border: 1px solid #ddd;
    display: inline-block;
    background: rgba(14, 196, 210, 0.99);
    color: #fff;
    text-align: center;
    margin-left: 20px;
    margin-top: 20px;
}

.submit{
    width: 150px;
    height: 35px;
    line-height: 35px;
    border-radius: 3px;
    border: 1px solid #ddd;
    display: inline-block;
    background: rgba(14, 196, 210, 0.99);
    color: #fff;
    text-align: center;
    margin: 5px auto;
}

.search-box .handle .title{
    width: 300px;
    margin: 0 auto;
}

.search-box .handle div{
    display: flex;
    margin-top: 40px;
    margin-left: 50px;
}

.search-box .handle select{
    vertical-align: middle;
}

.search-box .handle a{
    display: inline-block;
    width: 140px;
    height: 30px;
    border: 1px solid rgba(14, 196, 210, 0.99);
    line-height: 30px;
    text-align: center;
    border-radius: 5px;
    margin-left: 10px;
    vertical-align: middle;
    background: rgba(14, 196, 210, 0.99);
    color: #fff;
}
</style>

<div class="top">
    <span>欢迎管理员：admin</span>
</div>

<div class="left">
    <ul>
        <li><a href="#">查看注册字段</a></li>
        <li><a href="#">添加注册字段</a></li>
        <li><a href="#">查看表信息</a></li>
        <li><a href="">添加新表</a></li>
        <li><a href="./data_log.html">操作记录</a></li>
        <li class="selected"><a href="">数据备份</a></li>
    </ul>
</div>

<div class="right">
    <div class="search-box">
        <div class="handle">
            <div class="title"><h4>数据库名称：test</h4></div>
            <div>
                <h4>备份：</h4>
                <select name="" id="">
                    <option value="">请选择表</option>
                    <option value="">全部备份</option>
                    <option value="">users</option>
                    <option value="">goods</option>
                </select>
                <a href="">备份</a>
            </div>
            <div>
                <h4>恢复：</h4>
                <select name="" id="">
                    <option value="">请选择要恢复的文件</option>
                    <option value="">2017-11-19 09:00:00 - 全部数据</option>
                    <option value="">2017-11-19 08:00:00 - users</option>
                    <option value="">2017-11-19 08:00:00 - goods</option>
                </select>
                <a href="">恢复</a>
            </div>
        </div>
    </div>
</div>