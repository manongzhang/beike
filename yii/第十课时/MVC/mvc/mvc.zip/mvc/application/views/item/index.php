<form action="" method="get">
	<input type="text" value="<?= $keyword ?>" name="keyword">
	<input type="submit" value="搜索">
</form>

<p><a href="/item/manage">新建</a></p>

<table>
	<tr>
		<th>ID</th><th>内容</th><th>操作</th>
	</tr>
	<?php foreach ($items as $item): ?>
		<tr>
			<td><?= $item['id'] ?></td>
			<td><?= $item['item_name'] ?></td>
			<td>
				<a href="/item/manage/<?= $item['id'] ?>">编辑</a>
				<a href="/item/delete/<?= $item['id'] ?>">删除</a>
			</td>
		</tr>
	<?php endforeach ?>
</table>