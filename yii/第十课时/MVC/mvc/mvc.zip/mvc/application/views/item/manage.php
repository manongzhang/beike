<?php
if (isset($item['id'])) {
	$postUrl = "/item/update";
} else {
	$postUrl = "/item/add";
}
?>
<form action="<?= $postUrl; ?>" method="post">
	<?php if (isset($item['id'])): ?>
		<input type="hidden" name="id" value="<?= $item['id'] ?>">
	<?php endif; ?>
	<input type="text" name="value" value="<?= isset($item['item_name']) ? $item['item_name'] : '' ?>">
	<input type="submit" value="提交">
</form>

<a class="big" href="/item/index">返回</a>