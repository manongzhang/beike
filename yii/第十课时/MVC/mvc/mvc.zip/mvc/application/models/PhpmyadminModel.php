<?php

namespace application\models;

use fastphp\base\Model;
use fastphp\db\Db;

/**
* 
*/
class PhpmyadminModel extends Model
{
	
	protected $table = "user";

	// public function FunctionName($value='')
	// {
	// 	# code...
	// }
}