<?php

// 数据库配置
$config = [
	'db' => [
		'host' => '127.0.0.1',
		'username' => 'root',
		'password' => 'root',
		'dbname' => 'mvc'
	],
];

// 默认控制器和操作名
$config["defaultController"] = "Welcome";
$config["defaultAction"] = "index";

return $config;