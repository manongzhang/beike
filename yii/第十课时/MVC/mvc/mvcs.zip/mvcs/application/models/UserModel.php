<?php
	class UserModel extends Model
	{
		// 获取用户信息
		public function getUserinfo() {

		}
		public function updateUserpwd() {

		}
	}
?>