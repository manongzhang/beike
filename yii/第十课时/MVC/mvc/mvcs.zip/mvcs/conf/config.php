<?php
	$arrConfig = [
		"db" => [
			"host" => "127.0.0.1",
			"user" => "root",
			"pwd" => "root",
			"port" => "3306"
		],
	];
?>